import UIKit

/// Provides context-appropriate haptic feedback throughout the app.
/// Uses UIKit's high-level feedback generators (UIImpactFeedbackGenerator,
/// UINotificationFeedbackGenerator) rather than Core Haptics for simplicity.
class HapticsService {

    /// Sharp tap when camera captures an object
    func playCaptureFeedback() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    /// Satisfying buzz when translation succeeds
    func playSuccessFeedback() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    /// Soft confirmation when saving to a list
    func playSaveFeedback() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    /// Positive feedback for correct quiz/game answers
    func playCorrectFeedback() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    /// Error buzz for incorrect quiz/game answers
    func playIncorrectFeedback() {
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }

    /// Subtle tap for card flips
    func playFlipFeedback() {
        UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: 0.5)
    }
}
