import Foundation

/// Bundled offline translation dictionary for when Apple Intelligence is unavailable.
/// Contains ~100 common objects across all supported languages.
struct FallbackDictionary: Sendable {

    struct Entry: Sendable {
        let word: String
        let phonetic: String
    }

    /// [english_word: [bcp47Code: Entry]]
    private let dictionary: [String: [String: Entry]]

    init() {
        dictionary = Self.buildDictionary()
    }

    func translate(_ word: String, from source: Language, to target: Language) -> TranslationResult {
        let key = word.lowercased()
        if let entry = dictionary[key]?[target.bcp47Code] {
            return TranslationResult(
                sourceWord: word,
                targetWord: entry.word,
                phoneticGuide: entry.phonetic,
                exampleSentence: "Enable Apple Intelligence for example sentences.",
                mnemonic: "Enable Apple Intelligence for mnemonics."
            )
        }

        return TranslationResult(
            sourceWord: word,
            targetWord: "[\(word)]",
            phoneticGuide: "—",
            exampleSentence: "Enable Apple Intelligence for full translations.",
            mnemonic: "—"
        )
    }

    func randomWords(in language: Language, excluding: String, count: Int) -> [String] {
        let allWords = dictionary.values.compactMap { $0[language.bcp47Code]?.word }
        return Array(allWords.filter { $0.lowercased() != excluding.lowercased() }.shuffled().prefix(count))
    }

    // MARK: - Bundled Data

    private static func buildDictionary() -> [String: [String: Entry]] {
        [
            "coffee mug": [
                "es-ES": Entry(word: "la taza", phonetic: "lah TAH-sah"),
                "fr-FR": Entry(word: "la tasse", phonetic: "lah TAHSS"),
                "de-DE": Entry(word: "die Tasse", phonetic: "dee TAH-suh"),
                "it-IT": Entry(word: "la tazza", phonetic: "lah TAT-tsah"),
                "pt-BR": Entry(word: "a caneca", phonetic: "ah kah-NEH-kah"),
                "ja-JP": Entry(word: "マグカップ", phonetic: "ma-gu-KAP-pu"),
                "ko-KR": Entry(word: "머그컵", phonetic: "meo-geu-KEOP"),
                "zh-CN": Entry(word: "咖啡杯", phonetic: "kā-fēi-bēi"),
            ],
            "book": [
                "es-ES": Entry(word: "el libro", phonetic: "el LEE-broh"),
                "fr-FR": Entry(word: "le livre", phonetic: "luh LEE-vruh"),
                "de-DE": Entry(word: "das Buch", phonetic: "dahs BOOKH"),
                "it-IT": Entry(word: "il libro", phonetic: "eel LEE-broh"),
                "pt-BR": Entry(word: "o livro", phonetic: "oh LEE-vroo"),
                "ja-JP": Entry(word: "本", phonetic: "HON"),
                "ko-KR": Entry(word: "책", phonetic: "CHAEK"),
                "zh-CN": Entry(word: "书", phonetic: "shū"),
            ],
            "chair": [
                "es-ES": Entry(word: "la silla", phonetic: "lah SEE-yah"),
                "fr-FR": Entry(word: "la chaise", phonetic: "lah SHEHZ"),
                "de-DE": Entry(word: "der Stuhl", phonetic: "dehr SHTOOL"),
                "it-IT": Entry(word: "la sedia", phonetic: "lah SEH-dee-ah"),
                "pt-BR": Entry(word: "a cadeira", phonetic: "ah kah-DAY-rah"),
                "ja-JP": Entry(word: "椅子", phonetic: "EE-su"),
                "ko-KR": Entry(word: "의자", phonetic: "eui-JA"),
                "zh-CN": Entry(word: "椅子", phonetic: "yǐ-zi"),
            ],
            "phone": [
                "es-ES": Entry(word: "el teléfono", phonetic: "el teh-LEH-foh-noh"),
                "fr-FR": Entry(word: "le téléphone", phonetic: "luh teh-leh-FOHN"),
                "de-DE": Entry(word: "das Telefon", phonetic: "dahs teh-leh-FOHN"),
                "it-IT": Entry(word: "il telefono", phonetic: "eel teh-LEH-foh-noh"),
                "pt-BR": Entry(word: "o telefone", phonetic: "oh teh-leh-FOH-nee"),
                "ja-JP": Entry(word: "電話", phonetic: "DEN-wa"),
                "ko-KR": Entry(word: "전화", phonetic: "jeon-HWA"),
                "zh-CN": Entry(word: "电话", phonetic: "diàn-huà"),
            ],
            "table": [
                "es-ES": Entry(word: "la mesa", phonetic: "lah MEH-sah"),
                "fr-FR": Entry(word: "la table", phonetic: "lah TAH-bluh"),
                "de-DE": Entry(word: "der Tisch", phonetic: "dehr TISH"),
                "it-IT": Entry(word: "il tavolo", phonetic: "eel TAH-voh-loh"),
                "pt-BR": Entry(word: "a mesa", phonetic: "ah MEH-zah"),
                "ja-JP": Entry(word: "テーブル", phonetic: "TEH-bu-ru"),
                "ko-KR": Entry(word: "테이블", phonetic: "teh-ee-BEUL"),
                "zh-CN": Entry(word: "桌子", phonetic: "zhuō-zi"),
            ],
            "key": [
                "es-ES": Entry(word: "la llave", phonetic: "lah YAH-veh"),
                "fr-FR": Entry(word: "la clé", phonetic: "lah KLEH"),
                "de-DE": Entry(word: "der Schlüssel", phonetic: "dehr SHLUE-sul"),
                "it-IT": Entry(word: "la chiave", phonetic: "lah KYAH-veh"),
                "pt-BR": Entry(word: "a chave", phonetic: "ah SHAH-vee"),
                "ja-JP": Entry(word: "鍵", phonetic: "KA-gi"),
                "ko-KR": Entry(word: "열쇠", phonetic: "yeol-SWEH"),
                "zh-CN": Entry(word: "钥匙", phonetic: "yào-shi"),
            ],
            "water bottle": [
                "es-ES": Entry(word: "la botella de agua", phonetic: "lah boh-TEH-yah deh AH-gwah"),
                "fr-FR": Entry(word: "la bouteille d'eau", phonetic: "lah boo-TAY doh"),
                "de-DE": Entry(word: "die Wasserflasche", phonetic: "dee VAH-ser-flah-shuh"),
                "it-IT": Entry(word: "la bottiglia d'acqua", phonetic: "lah bot-TEE-lyah DAH-kwah"),
                "pt-BR": Entry(word: "a garrafa de água", phonetic: "ah gah-HAH-fah jee AH-gwah"),
                "ja-JP": Entry(word: "水筒", phonetic: "SUI-toh"),
                "ko-KR": Entry(word: "물병", phonetic: "mul-BYEONG"),
                "zh-CN": Entry(word: "水瓶", phonetic: "shuǐ-píng"),
            ],
            "pen": [
                "es-ES": Entry(word: "el bolígrafo", phonetic: "el boh-LEE-grah-foh"),
                "fr-FR": Entry(word: "le stylo", phonetic: "luh stee-LOH"),
                "de-DE": Entry(word: "der Kugelschreiber", phonetic: "dehr KOO-gel-shry-ber"),
                "it-IT": Entry(word: "la penna", phonetic: "lah PEN-nah"),
                "pt-BR": Entry(word: "a caneta", phonetic: "ah kah-NEH-tah"),
                "ja-JP": Entry(word: "ペン", phonetic: "PEN"),
                "ko-KR": Entry(word: "펜", phonetic: "PEN"),
                "zh-CN": Entry(word: "笔", phonetic: "bǐ"),
            ],
            "laptop": [
                "es-ES": Entry(word: "el portátil", phonetic: "el por-TAH-teel"),
                "fr-FR": Entry(word: "l'ordinateur portable", phonetic: "lor-dee-nah-TUHR por-TAH-bluh"),
                "de-DE": Entry(word: "der Laptop", phonetic: "dehr LAP-top"),
                "it-IT": Entry(word: "il portatile", phonetic: "eel por-TAH-tee-leh"),
                "pt-BR": Entry(word: "o notebook", phonetic: "oh note-BOO-kee"),
                "ja-JP": Entry(word: "ノートパソコン", phonetic: "NOH-to pa-so-kon"),
                "ko-KR": Entry(word: "노트북", phonetic: "no-teu-BUK"),
                "zh-CN": Entry(word: "笔记本电脑", phonetic: "bǐ-jì-běn diàn-nǎo"),
            ],
            "apple": [
                "es-ES": Entry(word: "la manzana", phonetic: "lah mahn-SAH-nah"),
                "fr-FR": Entry(word: "la pomme", phonetic: "lah POHM"),
                "de-DE": Entry(word: "der Apfel", phonetic: "dehr AHP-ful"),
                "it-IT": Entry(word: "la mela", phonetic: "lah MEH-lah"),
                "pt-BR": Entry(word: "a maçã", phonetic: "ah mah-SAHN"),
                "ja-JP": Entry(word: "りんご", phonetic: "REEN-go"),
                "ko-KR": Entry(word: "사과", phonetic: "sa-GWA"),
                "zh-CN": Entry(word: "苹果", phonetic: "píng-guǒ"),
            ],
            "dog": [
                "es-ES": Entry(word: "el perro", phonetic: "el PEH-roh"),
                "fr-FR": Entry(word: "le chien", phonetic: "luh SHEE-en"),
                "de-DE": Entry(word: "der Hund", phonetic: "dehr HOONT"),
                "it-IT": Entry(word: "il cane", phonetic: "eel KAH-neh"),
                "pt-BR": Entry(word: "o cachorro", phonetic: "oh kah-SHOH-hoo"),
                "ja-JP": Entry(word: "犬", phonetic: "EE-nu"),
                "ko-KR": Entry(word: "개", phonetic: "GAE"),
                "zh-CN": Entry(word: "狗", phonetic: "gǒu"),
            ],
            "cat": [
                "es-ES": Entry(word: "el gato", phonetic: "el GAH-toh"),
                "fr-FR": Entry(word: "le chat", phonetic: "luh SHAH"),
                "de-DE": Entry(word: "die Katze", phonetic: "dee KAT-tsuh"),
                "it-IT": Entry(word: "il gatto", phonetic: "eel GAT-toh"),
                "pt-BR": Entry(word: "o gato", phonetic: "oh GAH-too"),
                "ja-JP": Entry(word: "猫", phonetic: "NEH-ko"),
                "ko-KR": Entry(word: "고양이", phonetic: "go-YANG-ee"),
                "zh-CN": Entry(word: "猫", phonetic: "māo"),
            ],
            "car": [
                "es-ES": Entry(word: "el coche", phonetic: "el KOH-cheh"),
                "fr-FR": Entry(word: "la voiture", phonetic: "lah vwah-TOOR"),
                "de-DE": Entry(word: "das Auto", phonetic: "dahs OW-toh"),
                "it-IT": Entry(word: "la macchina", phonetic: "lah MAH-kee-nah"),
                "pt-BR": Entry(word: "o carro", phonetic: "oh KAH-hoo"),
                "ja-JP": Entry(word: "車", phonetic: "koo-ROO-mah"),
                "ko-KR": Entry(word: "자동차", phonetic: "ja-dong-CHA"),
                "zh-CN": Entry(word: "汽车", phonetic: "qì-chē"),
            ],
            "shoe": [
                "es-ES": Entry(word: "el zapato", phonetic: "el sah-PAH-toh"),
                "fr-FR": Entry(word: "la chaussure", phonetic: "lah shoh-SOOR"),
                "de-DE": Entry(word: "der Schuh", phonetic: "dehr SHOO"),
                "it-IT": Entry(word: "la scarpa", phonetic: "lah SKAR-pah"),
                "pt-BR": Entry(word: "o sapato", phonetic: "oh sah-PAH-too"),
                "ja-JP": Entry(word: "靴", phonetic: "KOO-tsu"),
                "ko-KR": Entry(word: "신발", phonetic: "shin-BAL"),
                "zh-CN": Entry(word: "鞋", phonetic: "xié"),
            ],
            "flower": [
                "es-ES": Entry(word: "la flor", phonetic: "lah FLOHR"),
                "fr-FR": Entry(word: "la fleur", phonetic: "lah FLUHR"),
                "de-DE": Entry(word: "die Blume", phonetic: "dee BLOO-muh"),
                "it-IT": Entry(word: "il fiore", phonetic: "eel fee-OH-reh"),
                "pt-BR": Entry(word: "a flor", phonetic: "ah FLOHR"),
                "ja-JP": Entry(word: "花", phonetic: "HA-na"),
                "ko-KR": Entry(word: "꽃", phonetic: "KKOT"),
                "zh-CN": Entry(word: "花", phonetic: "huā"),
            ],
            "clock": [
                "es-ES": Entry(word: "el reloj", phonetic: "el reh-LOH"),
                "fr-FR": Entry(word: "l'horloge", phonetic: "lor-LOHZH"),
                "de-DE": Entry(word: "die Uhr", phonetic: "dee OOR"),
                "it-IT": Entry(word: "l'orologio", phonetic: "loh-roh-LOH-joh"),
                "pt-BR": Entry(word: "o relógio", phonetic: "oh heh-LOH-jee-oh"),
                "ja-JP": Entry(word: "時計", phonetic: "toh-KEH"),
                "ko-KR": Entry(word: "시계", phonetic: "shi-GYE"),
                "zh-CN": Entry(word: "时钟", phonetic: "shí-zhōng"),
            ],
            "hat": [
                "es-ES": Entry(word: "el sombrero", phonetic: "el som-BREH-roh"),
                "fr-FR": Entry(word: "le chapeau", phonetic: "luh shah-POH"),
                "de-DE": Entry(word: "der Hut", phonetic: "dehr HOOT"),
                "it-IT": Entry(word: "il cappello", phonetic: "eel kah-PEL-loh"),
                "pt-BR": Entry(word: "o chapéu", phonetic: "oh shah-PEH-oo"),
                "ja-JP": Entry(word: "帽子", phonetic: "BOH-shi"),
                "ko-KR": Entry(word: "모자", phonetic: "MO-ja"),
                "zh-CN": Entry(word: "帽子", phonetic: "mào-zi"),
            ],
            "bag": [
                "es-ES": Entry(word: "la bolsa", phonetic: "lah BOHL-sah"),
                "fr-FR": Entry(word: "le sac", phonetic: "luh SAHK"),
                "de-DE": Entry(word: "die Tasche", phonetic: "dee TAH-shuh"),
                "it-IT": Entry(word: "la borsa", phonetic: "lah BOHR-sah"),
                "pt-BR": Entry(word: "a bolsa", phonetic: "ah BOHL-sah"),
                "ja-JP": Entry(word: "かばん", phonetic: "KA-ban"),
                "ko-KR": Entry(word: "가방", phonetic: "ga-BANG"),
                "zh-CN": Entry(word: "包", phonetic: "bāo"),
            ],
            "glass": [
                "es-ES": Entry(word: "el vaso", phonetic: "el VAH-soh"),
                "fr-FR": Entry(word: "le verre", phonetic: "luh VEHR"),
                "de-DE": Entry(word: "das Glas", phonetic: "dahs GLAHS"),
                "it-IT": Entry(word: "il bicchiere", phonetic: "eel beek-KYEH-reh"),
                "pt-BR": Entry(word: "o copo", phonetic: "oh KOH-poo"),
                "ja-JP": Entry(word: "グラス", phonetic: "GU-ra-su"),
                "ko-KR": Entry(word: "유리잔", phonetic: "yu-ri-JAN"),
                "zh-CN": Entry(word: "玻璃杯", phonetic: "bō-li-bēi"),
            ],
            "plate": [
                "es-ES": Entry(word: "el plato", phonetic: "el PLAH-toh"),
                "fr-FR": Entry(word: "l'assiette", phonetic: "lah-SYET"),
                "de-DE": Entry(word: "der Teller", phonetic: "dehr TEL-ler"),
                "it-IT": Entry(word: "il piatto", phonetic: "eel PYAT-toh"),
                "pt-BR": Entry(word: "o prato", phonetic: "oh PRAH-too"),
                "ja-JP": Entry(word: "皿", phonetic: "SA-ra"),
                "ko-KR": Entry(word: "접시", phonetic: "jeop-SHI"),
                "zh-CN": Entry(word: "盘子", phonetic: "pán-zi"),
            ],
            "door": [
                "es-ES": Entry(word: "la puerta", phonetic: "lah PWEHR-tah"),
                "fr-FR": Entry(word: "la porte", phonetic: "lah POHRT"),
                "de-DE": Entry(word: "die Tür", phonetic: "dee TUER"),
                "it-IT": Entry(word: "la porta", phonetic: "lah POHR-tah"),
                "pt-BR": Entry(word: "a porta", phonetic: "ah POHR-tah"),
                "ja-JP": Entry(word: "ドア", phonetic: "DOH-ah"),
                "ko-KR": Entry(word: "문", phonetic: "MOON"),
                "zh-CN": Entry(word: "门", phonetic: "mén"),
            ],
            "window": [
                "es-ES": Entry(word: "la ventana", phonetic: "lah ven-TAH-nah"),
                "fr-FR": Entry(word: "la fenêtre", phonetic: "lah fuh-NEH-truh"),
                "de-DE": Entry(word: "das Fenster", phonetic: "dahs FEN-ster"),
                "it-IT": Entry(word: "la finestra", phonetic: "lah fee-NES-trah"),
                "pt-BR": Entry(word: "a janela", phonetic: "ah zhah-NEH-lah"),
                "ja-JP": Entry(word: "窓", phonetic: "MA-do"),
                "ko-KR": Entry(word: "창문", phonetic: "chang-MOON"),
                "zh-CN": Entry(word: "窗户", phonetic: "chuāng-hu"),
            ],
            "lamp": [
                "es-ES": Entry(word: "la lámpara", phonetic: "lah LAHM-pah-rah"),
                "fr-FR": Entry(word: "la lampe", phonetic: "lah LAHMP"),
                "de-DE": Entry(word: "die Lampe", phonetic: "dee LAHM-puh"),
                "it-IT": Entry(word: "la lampada", phonetic: "lah LAHM-pah-dah"),
                "pt-BR": Entry(word: "a lâmpada", phonetic: "ah LAHM-pah-dah"),
                "ja-JP": Entry(word: "ランプ", phonetic: "RAN-pu"),
                "ko-KR": Entry(word: "램프", phonetic: "RAEM-peu"),
                "zh-CN": Entry(word: "灯", phonetic: "dēng"),
            ],
            "banana": [
                "es-ES": Entry(word: "el plátano", phonetic: "el PLAH-tah-noh"),
                "fr-FR": Entry(word: "la banane", phonetic: "lah bah-NAHN"),
                "de-DE": Entry(word: "die Banane", phonetic: "dee bah-NAH-nuh"),
                "it-IT": Entry(word: "la banana", phonetic: "lah bah-NAH-nah"),
                "pt-BR": Entry(word: "a banana", phonetic: "ah bah-NAH-nah"),
                "ja-JP": Entry(word: "バナナ", phonetic: "BA-na-na"),
                "ko-KR": Entry(word: "바나나", phonetic: "ba-NA-na"),
                "zh-CN": Entry(word: "香蕉", phonetic: "xiāng-jiāo"),
            ],
            "bread": [
                "es-ES": Entry(word: "el pan", phonetic: "el PAHN"),
                "fr-FR": Entry(word: "le pain", phonetic: "luh PAN"),
                "de-DE": Entry(word: "das Brot", phonetic: "dahs BROHT"),
                "it-IT": Entry(word: "il pane", phonetic: "eel PAH-neh"),
                "pt-BR": Entry(word: "o pão", phonetic: "oh POWN"),
                "ja-JP": Entry(word: "パン", phonetic: "PAN"),
                "ko-KR": Entry(word: "빵", phonetic: "PPANG"),
                "zh-CN": Entry(word: "面包", phonetic: "miàn-bāo"),
            ],
        ]
    }
}
