import AVFoundation
import SwiftUI

/// Manages the AVCaptureSession for live camera preview and frame capture
@MainActor
class CameraManager: NSObject, ObservableObject {
    @Published var isRunning = false
    @Published var isAuthorized = false

    let captureSession = AVCaptureSession()
    /// Most recent frame for Vision processing on tap.
    /// nonisolated(unsafe) because CVPixelBuffer isn't Sendable, but we only
    /// write from the delegate (dispatched on .main) and read from @MainActor methods.
    nonisolated(unsafe) private(set) var latestPixelBuffer: CVPixelBuffer?

    private let videoOutput = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "com.lenslingo.camera.session")
    private let bufferQueue = DispatchQueue(label: "com.lenslingo.camera.buffer")

    override init() {
        super.init()
        checkAuthorization()
    }

    // MARK: - Authorization

    private func checkAuthorization() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            isAuthorized = true
        case .notDetermined:
            Task {
                let granted = await AVCaptureDevice.requestAccess(for: .video)
                self.isAuthorized = granted
            }
        default:
            isAuthorized = false
        }
    }

    // MARK: - Session Lifecycle

    func startSession() {
        guard isAuthorized, !isRunning else { return }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.captureSession.beginConfiguration()
            self.captureSession.sessionPreset = .hd1920x1080

            guard let camera = AVCaptureDevice.default(
                .builtInWideAngleCamera, for: .video, position: .back
            ),
            let input = try? AVCaptureDeviceInput(device: camera) else {
                self.captureSession.commitConfiguration()
                return
            }

            if self.captureSession.canAddInput(input) {
                self.captureSession.addInput(input)
            }

            self.videoOutput.setSampleBufferDelegate(self, queue: .main)
            self.videoOutput.alwaysDiscardsLateVideoFrames = true

            if self.captureSession.canAddOutput(self.videoOutput) {
                self.captureSession.addOutput(self.videoOutput)
            }

            // Lock the video output to portrait orientation so pixel buffers
            // arrive upright. Without this, CGImages created from the buffer
            // appear rotated 90° because the camera sensor is landscape-native.
            if let connection = self.videoOutput.connection(with: .video) {
                connection.videoRotationAngle = 90
            }

            self.captureSession.commitConfiguration()
            self.captureSession.startRunning()

            DispatchQueue.main.async {
                self.isRunning = true
            }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            self?.captureSession.stopRunning()
            DispatchQueue.main.async {
                self?.isRunning = false
            }
        }
    }

    /// Returns the most recently captured pixel buffer for Vision processing
    func getCurrentFrame() -> CVPixelBuffer? {
        return latestPixelBuffer
    }
}

// MARK: - Video Output Delegate

extension CameraManager: @preconcurrency AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        // Store the original camera pixel buffer directly.
        // It must keep its IOSurface backing for VNGenerateForegroundInstanceMaskRequest to work.
        // Swift ARC retains the CVPixelBuffer so it stays alive until the next frame replaces it.
        self.latestPixelBuffer = pixelBuffer
    }
}
