import Vision
import UIKit
import CoreImage

/// Classifies and lifts individual subjects from camera frames using Vision.
///
/// Flow: tap on camera → get device-normalized point → run VNGenerateForegroundInstanceMaskRequest
/// → find which instance the tap hit → generate a masked image → classify that isolated subject.
///
/// Falls back to full-frame classification if lifting fails or isn't available.
final class VisionPipeline: Sendable {

    /// Wrapper to safely send a CVPixelBuffer across concurrency boundaries.
    /// The buffer is only read (never mutated) on the detached task, so this is safe.
    private struct SendableBuffer: @unchecked Sendable {
        let buffer: CVPixelBuffer
    }

    struct VisionResult: Sendable {
        let topLabels: [String]
        let croppedImageData: Data
        let detectedText: [String]
        let wasSubjectLifted: Bool
    }

    /// Classify the subject at the tapped device point using the raw pixel buffer.
    /// Using CVPixelBuffer directly (instead of a CGImage copy) preserves the IOSurface
    /// backing that VNGenerateForegroundInstanceMaskRequest requires.
    func classifySubject(pixelBuffer: CVPixelBuffer, at tapDevicePoint: CGPoint?) async -> VisionResult? {
        let wrapped = SendableBuffer(buffer: pixelBuffer)
        return await Task.detached { [self] in
            self.performOnBuffer(wrapped.buffer, tapDevicePoint: tapDevicePoint)
        }.value
    }

    /// Convenience overload: classify a CGImage (used when pixel buffer isn't available).
    func classifySubject(in cgImage: CGImage, at tapPoint: CGPoint?) async -> VisionResult? {
        return await Task.detached { [self] in
            self.performOnCGImage(cgImage, tapPoint: tapPoint)
        }.value
    }

    // MARK: - Core Pipeline (Pixel Buffer path — preferred)

    private func performOnBuffer(_ pixelBuffer: CVPixelBuffer, tapDevicePoint: CGPoint?) -> VisionResult? {
        // Vision's VNImageRequestHandler with a pixel buffer gives best results
        // because it can access the IOSurface directly for instance mask generation.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        let bufferWidth = CVPixelBufferGetWidth(pixelBuffer)
        let bufferHeight = CVPixelBufferGetHeight(pixelBuffer)

        // Step 1: Try to lift the subject at the tap point
        var liftedCGImage: CGImage?
        if let tap = tapDevicePoint, #available(iOS 17, *) {
            liftedCGImage = liftSubject(
                handler: handler,
                tapDevicePoint: tap,
                imageWidth: bufferWidth,
                imageHeight: bufferHeight
            )
        }

        // Step 2: If lifting failed, create a full-frame CGImage as fallback
        let fullFrameImage: CGImage
        let ciCtx = CIContext()
        let ci = CIImage(cvPixelBuffer: pixelBuffer)
        guard let full = ciCtx.createCGImage(ci, from: ci.extent) else { return nil }
        fullFrameImage = full

        let wasLifted = liftedCGImage != nil
        let imageForClassification = liftedCGImage ?? fullFrameImage

        // Step 3: Classify the (lifted or full) image
        return classify(
            image: imageForClassification,
            wasLifted: wasLifted
        )
    }

    // MARK: - Core Pipeline (CGImage fallback path)

    private func performOnCGImage(_ cgImage: CGImage, tapPoint: CGPoint?) -> VisionResult? {
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        var liftedCGImage: CGImage?
        if let tap = tapPoint, #available(iOS 17, *) {
            liftedCGImage = liftSubject(
                handler: handler,
                tapDevicePoint: tap,
                imageWidth: cgImage.width,
                imageHeight: cgImage.height
            )
        }

        let wasLifted = liftedCGImage != nil
        let imageForClassification = liftedCGImage ?? cgImage

        return classify(image: imageForClassification, wasLifted: wasLifted)
    }

    // MARK: - Classification

    /// Run VNClassifyImageRequest + VNRecognizeTextRequest on an image.
    private func classify(image: CGImage, wasLifted: Bool) -> VisionResult? {
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        let classReq = VNClassifyImageRequest()
        let textReq = VNRecognizeTextRequest()
        textReq.recognitionLevel = .accurate

        do {
            try handler.perform([classReq, textReq])
        } catch {
            print("VisionPipeline: classification failed — \(error)")
            return nil
        }

        // Filter out generic/unhelpful Vision labels
        let generic: Set<String> = [
            "structure", "outdoor", "indoor", "sky", "text", "screenshot",
            "abstract", "close-up", "horizontal", "vertical", "blurry", "pattern"
        ]
        let topLabels = (classReq.results ?? [])
            .filter { $0.confidence > 0.05 }
            .prefix(15)
            .map { cleanLabel($0.identifier) }
            .filter { !generic.contains($0.lowercased()) }

        let labels = Array(topLabels.prefix(5))
        guard !labels.isEmpty else { return nil }

        // PNG for lifted (preserves transparency), JPEG for full-frame (smaller)
        let uiImage = UIImage(cgImage: image)
        let imageData: Data = wasLifted
            ? (uiImage.pngData() ?? Data())
            : (uiImage.jpegData(compressionQuality: 0.85) ?? Data())

        let texts = textReq.results?
            .compactMap { $0.topCandidates(1).first?.string } ?? []

        return VisionResult(
            topLabels: labels,
            croppedImageData: imageData,
            detectedText: texts,
            wasSubjectLifted: wasLifted
        )
    }

    // MARK: - Subject Lifting

    /// Isolates the foreground instance closest to the tap point.
    ///
    /// `tapDevicePoint` is in AVFoundation's device coordinate space:
    ///   - (0,0) = top-left of camera sensor output
    ///   - (1,1) = bottom-right
    ///
    /// Vision's coordinate space has (0,0) at bottom-left, so we flip Y
    /// when mapping to the mask's pixel grid.
    @available(iOS 17, *)
    private func liftSubject(
        handler: VNImageRequestHandler,
        tapDevicePoint: CGPoint,
        imageWidth: Int,
        imageHeight: Int
    ) -> CGImage? {
        let maskReq = VNGenerateForegroundInstanceMaskRequest()
        do {
            try handler.perform([maskReq])
        } catch {
            print("VisionPipeline: instance mask request failed — \(error)")
            return nil
        }

        guard let observation = maskReq.results?.first else {
            print("VisionPipeline: no instance mask results")
            return nil
        }

        let allInstances = observation.allInstances
        guard !allInstances.isEmpty else {
            print("VisionPipeline: no foreground instances found")
            return nil
        }

        // Convert device point to pixel coordinates in the mask.
        // Device coords: (0,0) top-left. Mask/image coords: also top-left origin
        // since generateScaledMaskForImage returns a buffer matching the source orientation.
        let imgW = CGFloat(imageWidth)
        let imgH = CGFloat(imageHeight)
        let pixX = Int((tapDevicePoint.x * imgW).clamped(to: 0...(imgW - 1)))
        let pixY = Int((tapDevicePoint.y * imgH).clamped(to: 0...(imgH - 1)))

        // Find which specific foreground instance the user tapped on
        var chosenInstances: IndexSet = allInstances  // fallback: all instances

        for idx in allInstances {
            guard let maskBuf = try? observation.generateScaledMaskForImage(
                forInstances: IndexSet(integer: idx),
                from: handler
            ) else { continue }

            if sampleMask(maskBuf, atX: pixX, y: pixY) {
                chosenInstances = IndexSet(integer: idx)
                print("VisionPipeline: tapped on instance \(idx)")
                break
            }
        }

        // Generate the isolated subject with transparent background,
        // cropped tightly to the instance bounds so the subject fills the frame.
        guard let maskedBuf = try? observation.generateMaskedImage(
            ofInstances: chosenInstances,
            from: handler,
            croppedToInstancesExtent: true
        ) else {
            print("VisionPipeline: generateMaskedImage failed")
            return nil
        }

        let ci = CIImage(cvPixelBuffer: maskedBuf)
        return CIContext().createCGImage(ci, from: ci.extent)
    }

    /// Returns true if the single-channel mask buffer has a foreground pixel at (x, y).
    private func sampleMask(_ buf: CVPixelBuffer, atX x: Int, y: Int) -> Bool {
        CVPixelBufferLockBaseAddress(buf, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buf, .readOnly) }

        let w = CVPixelBufferGetWidth(buf)
        let h = CVPixelBufferGetHeight(buf)
        guard x >= 0, x < w, y >= 0, y < h else { return false }

        guard let base = CVPixelBufferGetBaseAddress(buf) else { return false }
        let bpr = CVPixelBufferGetBytesPerRow(buf)
        let fmt = CVPixelBufferGetPixelFormatType(buf)

        switch fmt {
        case kCVPixelFormatType_OneComponent8:
            let ptr = base.assumingMemoryBound(to: UInt8.self)
            return ptr[y * bpr + x] > 127
        case kCVPixelFormatType_OneComponent32Float:
            let ptr = base.assumingMemoryBound(to: Float.self)
            let stride = bpr / MemoryLayout<Float>.size
            return ptr[y * stride + x] > 0.5
        default:
            return false
        }
    }

    private func cleanLabel(_ raw: String) -> String {
        raw.replacingOccurrences(of: "_", with: " ")
            .split(separator: ",").first.map(String.init) ?? raw
    }
}

// MARK: - Helpers

private extension Comparable {
    func clamped(to range: ClosedRange<Self>) -> Self {
        min(max(self, range.lowerBound), range.upperBound)
    }
}
