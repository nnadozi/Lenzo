import FoundationModels
import SwiftUI

/// Translates objects using on-device Foundation Models, with a bundled dictionary fallback
@MainActor
class TranslationService: ObservableObject {
    @Published var isAvailable = false

    private var session: LanguageModelSession?
    private let fallback = FallbackDictionary()

    init() {
        checkAvailability()
    }

    func checkAvailability() {
        let available = SystemLanguageModel.default.isAvailable
        isAvailable = available
        if available {
            session = LanguageModelSession(
                instructions: """
                You are a language learning assistant. You provide accurate translations,
                helpful pronunciation guides using English phonetic approximations,
                and natural example sentences with their English translations.
                Keep responses concise and learner-friendly.
                """
            )
        }
    }

    // MARK: - Translate Object

    /// Accepts multiple Vision classification hints and lets FM identify the specific object
    func translate(classificationHints: [String], from source: Language, to target: Language) async -> TranslationResult {
        let hintsText = classificationHints.joined(separator: ", ")

        guard let session, isAvailable else {
            return fallback.translate(classificationHints.first ?? "object", from: source, to: target)
        }

        do {
            let prompt = """
            A camera is looking at a real-world object. Image classification suggests \
            these labels (most confident first): \(hintsText).

            Identify the most likely specific, everyday object name in \(source.rawValue). \
            Then translate it to \(target.rawValue).
            Provide a phonetic pronunciation guide using English letters.
            For exampleSentence: write a simple sentence in \(source.rawValue) using the object name.
            For mnemonic: translate that same sentence into \(target.rawValue).
            """

            let response = try await session.respond(to: prompt, generating: TranslationResult.self)
            return response.content
        } catch {
            print("Foundation Models translation error: \(error)")
            return fallback.translate(classificationHints.first ?? "object", from: source, to: target)
        }
    }

    // MARK: - Generate Quiz Distractors

    func generateDistractors(for word: String, in language: Language, count: Int = 3) async -> [String] {
        guard let session, isAvailable else {
            return fallback.randomWords(in: language, excluding: word, count: count)
        }

        do {
            let prompt = """
            Give me \(count) plausible but incorrect \(language.rawValue) translations for "\(word)".
            They should be common words from similar categories to make the quiz challenging.
            """

            let response = try await session.respond(to: prompt, generating: QuizDistractors.self)
            return response.content.distractors
        } catch {
            return fallback.randomWords(in: language, excluding: word, count: count)
        }
    }

    // MARK: - Generate Sentence

    func generateSentence(using word: String, in language: Language) async -> SentenceGeneration? {
        guard let session, isAvailable else { return nil }

        do {
            let prompt = """
            Create a simple, natural sentence in \(language.rawValue) using the word "\(word)".
            Also provide the English translation.
            """

            let response = try await session.respond(to: prompt, generating: SentenceGeneration.self)
            return response.content
        } catch {
            return nil
        }
    }

    // MARK: - Fill in the Blank

    func generateFillInBlank(for word: String, in language: Language) async -> FillInTheBlank? {
        guard let session, isAvailable else { return nil }

        do {
            let prompt = """
            Create a fill-in-the-blank exercise. Write a sentence in \(language.rawValue)
            using "\(word)", but replace that word with "______".
            Provide the English translation (also with a blank) and the answer.
            """

            let response = try await session.respond(to: prompt, generating: FillInTheBlank.self)
            return response.content
        } catch {
            return nil
        }
    }

    // MARK: - Phrase Translation

    /// Translates a conversational phrase and provides pronunciation + usage context
    func translatePhrase(_ phrase: String, from source: Language, to target: Language) async -> PhraseTranslation? {
        guard let session, isAvailable else { return nil }

        do {
            let prompt = """
            Translate this \(source.rawValue) phrase to \(target.rawValue): "\(phrase)"
            Provide an accurate phonetic pronunciation guide using English letters.
            Add a short, helpful context note about when or how to use this phrase.
            """

            let response = try await session.respond(to: prompt, generating: PhraseTranslation.self)
            return response.content
        } catch {
            print("Phrase translation error: \(error)")
            return nil
        }
    }

    // MARK: - Phrase Chatbot

    /// Answers a user question about a specific phrase in a conversational way.
    func chatAboutPhrase(
        question: String,
        phrase: String,
        translatedPhrase: String,
        from source: Language,
        to target: Language
    ) async -> String? {
        guard let session, isAvailable else { return nil }

        do {
            let prompt = """
            The user is learning \(target.rawValue). Today's phrase is:
            \(source.rawValue): "\(phrase)"
            \(target.rawValue): "\(translatedPhrase)"

            The user asks: "\(question)"

            Give a helpful, concise answer. You can explain grammar, give more examples,
            explain cultural context, or provide related phrases. Keep it friendly and learner-focused.
            """

            let response = try await session.respond(to: prompt, generating: PhraseChatReply.self)
            return response.content.reply
        } catch {
            print("Phrase chat error: \(error)")
            return nil
        }
    }

    // MARK: - Conversation Practice

    /// Creates a dedicated session for a conversation practice scenario.
    /// Returns a ConversationSession that maintains multi-turn context.
    func createConversationSession(
        scenario: String,
        target: Language
    ) -> ConversationSession {
        ConversationSession(scenario: scenario, targetLanguage: target, fallback: fallback)
    }
}

// MARK: - Conversation Session

/// Manages a multi-turn roleplay conversation with the on-device language model.
/// Each instance has its own LanguageModelSession so conversation history is preserved.
@MainActor
class ConversationSession: ObservableObject {
    let scenario: String
    let targetLanguage: Language

    private var session: LanguageModelSession?
    private let fallback: FallbackDictionary
    var isAvailable: Bool { session != nil }

    init(scenario: String, targetLanguage: Language, fallback: FallbackDictionary) {
        self.scenario = scenario
        self.targetLanguage = targetLanguage
        self.fallback = fallback

        if SystemLanguageModel.default.isAvailable {
            self.session = LanguageModelSession(
                instructions: """
                You are a friendly conversation partner helping someone practice \(targetLanguage.rawValue).
                Scenario: \(scenario).

                Rules:
                - Stay in character for the scenario.
                - Keep your replies short (1-2 sentences) so the learner can follow along.
                - Use simple, everyday \(targetLanguage.rawValue) appropriate for a beginner/intermediate learner.
                - Always suggest 3 short things the user could say next in \(targetLanguage.rawValue).
                - Be encouraging and natural.
                """
            )
        }
    }

    /// Start the conversation — the AI says the opening line.
    func startConversation() async -> ConversationTurn? {
        guard let session else { return nil }

        do {
            let prompt = """
            Start the conversation. Say a natural opening line in \(targetLanguage.rawValue) \
            appropriate for this scenario: "\(scenario)".
            Keep it short and beginner-friendly.
            """
            let response = try await session.respond(to: prompt, generating: ConversationTurn.self)
            return response.content
        } catch {
            print("ConversationSession start error: \(error)")
            return nil
        }
    }

    /// Send the user's reply and get the AI partner's next response.
    func reply(userMessage: String) async -> ConversationTurn? {
        guard let session else { return nil }

        do {
            let prompt = """
            The user says: "\(userMessage)"
            Continue the conversation naturally in \(targetLanguage.rawValue). \
            Keep your reply short (1-2 sentences).
            """
            let response = try await session.respond(to: prompt, generating: ConversationTurn.self)
            return response.content
        } catch {
            print("ConversationSession reply error: \(error)")
            return nil
        }
    }
}
