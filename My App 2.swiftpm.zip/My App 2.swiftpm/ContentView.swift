import SwiftUI
import FoundationModels

/// Root view: checks for Apple Intelligence, gates onboarding, then shows the main 3-tab interface
struct ContentView: View {
    @EnvironmentObject var appState: AppState

    /// Whether the device supports Apple Intelligence (on-device Foundation Models)
    private var supportsAppleIntelligence: Bool {
        SystemLanguageModel.default.isAvailable
    }

    var body: some View {
        if !supportsAppleIntelligence {
            UnsupportedDeviceView()
        } else if appState.hasCompletedOnboarding {
            mainTabView
        } else {
            OnboardingFlow()
        }
    }

    private var mainTabView: some View {
        TabView(selection: $appState.selectedTab) {
            Tab("Camera", systemImage: "camera.viewfinder", value: 0) {
                CameraView()
            }

            Tab("Word Lists", systemImage: "rectangle.stack", value: 1) {
                WordListsView()
            }

            Tab("Practice", systemImage: "bubble.left.and.bubble.right.fill", value: 2) {
                PhrasesView()
            }

            Tab("Settings", systemImage: "gearshape", value: 3) {
                SettingsView()
            }
        }
    }
}

/// Shown when the device doesn't have Apple Intelligence available
struct UnsupportedDeviceView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.red.opacity(0.8), .orange.opacity(0.7)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 24) {
                Image(systemName: "apple.intelligence")
                    .font(.system(size: 70, weight: .thin))
                    .foregroundStyle(.white)

                Text("Apple Intelligence Required")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)

                Text("Lenzo uses on-device AI to identify objects and translate them in real time. This feature requires Apple Intelligence, which is not available on this device.")
                    .font(.body)
                    .foregroundStyle(.white.opacity(0.85))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)

                VStack(spacing: 12) {
                    Label("iPhone 16 or later", systemImage: "iphone")
                    Label("iPad with M1 chip or later", systemImage: "ipad")
                    Label("iOS 26 or later", systemImage: "gear")
                }
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.7))

                Text("Please try again on a supported device.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.5))
                    .padding(.top, 8)
            }
            .padding()
        }
    }
}
