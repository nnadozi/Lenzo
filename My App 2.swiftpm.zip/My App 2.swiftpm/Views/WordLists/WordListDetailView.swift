import SwiftUI

/// Shows all items in a word list with a practice button and swipe actions
struct WordListDetailView: View {
    @EnvironmentObject var appState: AppState
    let wordList: WordList

    @State private var showGamePicker = false
    @State private var selectedItem: VocabItem?

    /// Always read the freshest data from appState
    private var currentList: WordList? {
        appState.wordLists.first(where: { $0.id == wordList.id })
    }

    var body: some View {
        List {
            // Practice banner (requires at least 3 items)
            if let list = currentList {
                Section {
                    if list.itemCount >= 3 {
                        Button {
                            showGamePicker = true
                        } label: {
                            HStack {
                                Image(systemName: "gamecontroller.fill")
                                    .font(.title2)
                                    .foregroundStyle(.green)

                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Practice This List")
                                        .font(.headline)
                                    Text("\(list.itemCount) words ready to practice")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer()

                                Text("Go")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 6)
                                    .background(.green, in: Capsule())
                            }
                            .padding(.vertical, 4)
                        }
                        .buttonStyle(.plain)
                    } else {
                        HStack {
                            Image(systemName: "gamecontroller")
                                .font(.title2)
                                .foregroundStyle(.secondary)

                            VStack(alignment: .leading, spacing: 2) {
                                Text("Practice This List")
                                    .font(.headline)
                                    .foregroundStyle(.secondary)
                                Text("Add \(3 - list.itemCount) more word\(3 - list.itemCount == 1 ? "" : "s") to unlock games")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }

            // Vocab items
            Section("Words") {
                if let list = currentList {
                    ForEach(list.items) { item in
                        VocabItemRow(item: item)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                selectedItem = item
                            }
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) {
                                    appState.removeItemFromList(itemId: item.id, listId: wordList.id)
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading) {
                                Button {
                                    appState.toggleStarItem(itemId: item.id, listId: wordList.id)
                                } label: {
                                    Label(
                                        item.isStarred ? "Unstar" : "Star",
                                        systemImage: item.isStarred ? "star.slash" : "star.fill"
                                    )
                                }
                                .tint(.yellow)
                            }
                    }
                }
            }
        }
        .navigationTitle("\(wordList.emoji) \(wordList.name)")
        .sheet(isPresented: $showGamePicker) {
            if let list = currentList {
                GamePickerSheet(wordList: list)
                    .presentationDetents([.medium])
            }
        }
        .sheet(item: $selectedItem) { item in
            TranslationCardView(vocabItem: item)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
    }
}
