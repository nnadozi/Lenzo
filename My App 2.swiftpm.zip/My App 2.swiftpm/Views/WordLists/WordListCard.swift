import SwiftUI

/// A card showing a word list preview in the grid (emoji, name, count, thumbnail images)
struct WordListCard: View {
    let wordList: WordList

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Preview thumbnails (up to 4 captured subjects in a 2x2 grid)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 4) {
                ForEach(wordList.items.prefix(4)) { item in
                    if let img = UIImage(data: item.capturedImageData) {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 40)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                    } else {
                        RoundedRectangle(cornerRadius: 6)
                            .fill(.quaternary)
                            .frame(height: 40)
                    }
                }

                // Fill remaining slots with placeholders if fewer than 4 items
                if wordList.items.count < 4 {
                    ForEach(0..<(4 - min(wordList.items.count, 4)), id: \.self) { _ in
                        RoundedRectangle(cornerRadius: 6)
                            .fill(.quaternary)
                            .frame(height: 40)
                    }
                }
            }
            .frame(height: 88)

            HStack {
                Text(wordList.emoji)
                Text(wordList.name)
                    .font(.headline)
                    .lineLimit(1)
            }

            Text("\(wordList.itemCount) words")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .glassEffect(.regular, in: .rect(cornerRadius: 20))
    }
}
