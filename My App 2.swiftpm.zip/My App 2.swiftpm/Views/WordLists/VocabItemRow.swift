import SwiftUI

/// A row displaying a single vocabulary item in a word list detail view
struct VocabItemRow: View {
    let item: VocabItem

    private let speech = SpeechService()

    var body: some View {
        HStack(spacing: 12) {
            // Thumbnail of captured object
            if let img = UIImage(data: item.capturedImageData) {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            } else {
                RoundedRectangle(cornerRadius: 10)
                    .fill(.quaternary)
                    .frame(width: 50, height: 50)
            }

            // Word info
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 4) {
                    Text(item.sourceWord)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text("→")
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                    Text(item.targetWord)
                        .font(.headline)
                }

                Text("/\(item.phoneticGuide)/")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .italic()
            }

            Spacer()

            // Star indicator
            if item.isStarred {
                Image(systemName: "star.fill")
                    .foregroundStyle(.yellow)
                    .font(.caption)
            }

            // Speak button
            Button {
                speech.speak(item.targetWord, in: item.targetLanguage)
            } label: {
                Image(systemName: "speaker.wave.2.fill")
                    .foregroundStyle(.blue)
                    .font(.subheadline)
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 4)
    }
}
