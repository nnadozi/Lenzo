import SwiftUI

/// Standalone sheet for creating a new empty word list (from the Word Lists tab)
struct CreateListSheet: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var selectedEmoji = "📚"

    private let emojiOptions = [
        "📚", "🍕", "🏠", "✈️", "🎒", "🛒", "🌍", "🎵", "⚽", "🐾", "🌸", "💼",
        "🍳", "🚗", "🏖️", "🎨", "🧪", "🏋️", "🎮", "🩺", "👕", "🛋️", "🌲", "🎂",
        "📱", "🧸", "🏫", "🎭", "🐶", "🍎", "☕", "🔧", "✏️", "🎤", "🧑‍🍳", "🏆"
    ]

    var body: some View {
        NavigationStack {
            VStack(spacing: 28) {
                // Large selected emoji preview
                Text(selectedEmoji)
                    .font(.system(size: 64))
                    .padding(.top, 20)

                // Emoji picker row
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(emojiOptions, id: \.self) { emoji in
                            Button {
                                withAnimation(.spring(response: 0.3)) {
                                    selectedEmoji = emoji
                                }
                            } label: {
                                Text(emoji)
                                    .font(.title2)
                                    .padding(10)
                                    .background(
                                        Circle()
                                            .fill(selectedEmoji == emoji ? Color.blue.opacity(0.2) : Color.clear)
                                    )
                            }
                        }
                    }
                    .padding(.horizontal)
                }

                // Name field
                VStack(alignment: .leading, spacing: 6) {
                    Text("List Name")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    TextField("e.g. Kitchen, Travel, Animals", text: $name)
                        .font(.body)
                        .padding(12)
                        .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 12))
                }
                .padding(.horizontal, 24)

                Spacer()
            }
            .navigationTitle("New Word List")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Create") {
                        appState.addWordList(
                            name: name.trimmingCharacters(in: .whitespaces),
                            emoji: selectedEmoji
                        )
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }
}
