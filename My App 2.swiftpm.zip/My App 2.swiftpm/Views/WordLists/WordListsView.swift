import SwiftUI

/// Tab 2: Grid of user's word list collections
struct WordListsView: View {
    @EnvironmentObject var appState: AppState
    @State private var showCreateSheet = false

    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        NavigationStack {
            Group {
                if appState.wordLists.isEmpty {
                    emptyState
                } else {
                    listGrid
                }
            }
            .navigationTitle("My Word Lists")
            .sheet(isPresented: $showCreateSheet) {
                CreateListSheet()
            }
        }
    }

    // MARK: - Grid

    private var listGrid: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(appState.wordLists) { list in
                    NavigationLink(destination: WordListDetailView(wordList: list)) {
                        WordListCard(wordList: list)
                    }
                    .buttonStyle(.plain)
                }

                // Add new list card
                Button {
                    showCreateSheet = true
                } label: {
                    VStack(spacing: 12) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 32))
                            .foregroundStyle(.blue)
                        Text("New List")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.blue)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 160)
                    .glassEffect(.regular, in: .rect(cornerRadius: 20))
                }
                .buttonStyle(.plain)
            }
            .padding()
        }
    }

    // MARK: - Empty State

    private var emptyState: some View {
        VStack(spacing: 20) {
            Spacer()

            Image(systemName: "rectangle.stack.badge.plus")
                .font(.system(size: 60, weight: .thin))
                .foregroundStyle(.secondary)

            Text("No Word Lists Yet")
                .font(.title2.weight(.semibold))

            Text("Start capturing words to build your first list!")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)

            Button {
                appState.selectedTab = 0
            } label: {
                Label("Open Camera", systemImage: "camera.fill")
                    .font(.headline)
            }
            .glassButton(tint: .blue)

            Spacer()
        }
    }
}
