import SwiftUI

/// Sheet that lets users pick an existing word list or create a new one to save a vocab item
struct ListPickerSheet: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss

    let vocabItem: VocabItem
    let onSaved: () -> Void

    @State private var showCreateNew = false
    @State private var newListName = ""
    @State private var newListEmoji = "📚"

    private let emojiOptions = [
        "📚", "🍕", "🏠", "✈️", "🎒", "🛒", "🌍", "🎵", "⚽", "🐾", "🌸", "💼",
        "🍳", "🚗", "🏖️", "🎨", "🧪", "🏋️", "🎮", "🩺", "👕", "🛋️", "🌲", "🎂",
        "📱", "🧸", "🏫", "🎭", "🐶", "🍎", "☕", "🔧", "✏️", "🎤", "🧑‍🍳", "🏆"
    ]

    var body: some View {
        NavigationStack {
            Group {
                if appState.wordLists.isEmpty || showCreateNew {
                    createNewListView
                } else {
                    existingListsView
                }
            }
            .navigationTitle("Save to List")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }

    // MARK: - Existing Lists

    private var existingListsView: some View {
        List {
            ForEach(appState.wordLists) { list in
                Button {
                    appState.addItemToList(item: vocabItem, listId: list.id)
                    onSaved()
                    dismiss()
                } label: {
                    HStack {
                        Text(list.emoji)
                            .font(.title2)
                        VStack(alignment: .leading) {
                            Text(list.name)
                                .font(.headline)
                            Text("\(list.itemCount) words")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "plus.circle")
                            .foregroundStyle(.blue)
                    }
                }
                .buttonStyle(.plain)
            }

            Button {
                showCreateNew = true
            } label: {
                Label("New List", systemImage: "plus.circle.fill")
                    .font(.headline)
                    .foregroundStyle(.blue)
            }
        }
    }

    // MARK: - Create New List

    private var createNewListView: some View {
        VStack(spacing: 24) {
            Text("Create a New List")
                .font(.headline)
                .padding(.top)

            // Emoji picker
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(emojiOptions, id: \.self) { emoji in
                        Button {
                            newListEmoji = emoji
                        } label: {
                            Text(emoji)
                                .font(.title)
                                .padding(8)
                                .background(
                                    Circle()
                                        .fill(newListEmoji == emoji ? Color.blue.opacity(0.2) : Color.clear)
                                )
                        }
                    }
                }
                .padding(.horizontal)
            }

            // Name field
            TextField("List name", text: $newListName)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal, 24)

            // Create button
            Button {
                guard !newListName.trimmingCharacters(in: .whitespaces).isEmpty else { return }
                let newList = WordList(
                    id: UUID(),
                    name: newListName.trimmingCharacters(in: .whitespaces),
                    emoji: newListEmoji,
                    items: [vocabItem],
                    createdAt: Date()
                )
                appState.wordLists.append(newList)
                onSaved()
                dismiss()
            } label: {
                Text("Create & Save")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
            }
            .glassButton(tint: .blue)
            .padding(.horizontal, 24)
            .disabled(newListName.trimmingCharacters(in: .whitespaces).isEmpty)

            Spacer()
        }
    }
}
