import SwiftUI

/// 6-page onboarding experience introducing Lenzo's features
struct OnboardingFlow: View {
    @EnvironmentObject var appState: AppState
    @State private var currentPage = 0

    private let totalPages = 6

    var body: some View {
        ZStack {
            // Animated gradient background
            LinearGradient(
                colors: gradientColors(for: currentPage),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.6), value: currentPage)

            VStack(spacing: 0) {
                Spacer()

                // Page content
                TabView(selection: $currentPage) {
                    welcomePage.tag(0)
                    capturePage.tag(1)
                    translationPage.tag(2)
                    collectionsPage.tag(3)
                    gamesPage.tag(4)
                    conversationPage.tag(5)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))

                Spacer()

                // Page indicators + button
                VStack(spacing: 20) {
                    pageIndicators

                    actionButton
                        .padding(.horizontal, 40)
                }
                .padding(.bottom, 50)
            }
        }
    }

    // MARK: - Pages

    private var welcomePage: some View {
        OnboardingPage(
            icon: "camera.viewfinder",
            title: "Welcome to Lenzo",
            description: "Point. Tap. Learn. Turn the world around you into your personal language classroom.",
            note: "Requires Apple Intelligence (iOS 26+)"
        )
    }

    private var capturePage: some View {
        OnboardingPage(
            icon: "hand.tap",
            title: "Tap Any Object",
            description: "Point your camera at anything — a cup, a book, your keys — and tap it. Lenzo lifts the object right off the screen and identifies it instantly."
        )
    }

    private var translationPage: some View {
        OnboardingPage(
            icon: "character.book.closed",
            title: "Learn in Any Language",
            description: "Get instant translations with pronunciation guides, example sentences, and fun memory tricks — all powered by on-device AI. No internet needed."
        )
    }

    private var collectionsPage: some View {
        OnboardingPage(
            icon: "rectangle.stack",
            title: "Build Word Lists",
            description: "Save words to custom collections. Organize by topic, trip, or whatever works for you."
        )
    }

    private var gamesPage: some View {
        OnboardingPage(
            icon: "gamecontroller",
            title: "Practice & Play",
            description: "Flashcards, memory match, sentence building — turn your captured words into lasting knowledge."
        )
    }

    private var conversationPage: some View {
        OnboardingPage(
            icon: "bubble.left.and.bubble.right",
            title: "Conversation Practice",
            description: "Chat with an AI partner in real-world scenarios — ordering coffee, checking into a hotel, or meeting someone new. Practice speaking naturally."
        )
    }

    // MARK: - Navigation

    private var pageIndicators: some View {
        HStack(spacing: 8) {
            ForEach(0..<totalPages, id: \.self) { index in
                Circle()
                    .fill(index == currentPage ? Color.white : Color.white.opacity(0.4))
                    .frame(width: index == currentPage ? 10 : 8, height: index == currentPage ? 10 : 8)
                    .animation(.spring(response: 0.3), value: currentPage)
            }
        }
    }

    private var actionButton: some View {
        Button {
            if currentPage < totalPages - 1 {
                withAnimation { currentPage += 1 }
            } else {
                withAnimation { appState.hasCompletedOnboarding = true }
            }
        } label: {
            Text(currentPage < totalPages - 1 ? "Next" : "Get Started")
                .font(.headline)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .glassEffect(
                    currentPage < totalPages - 1
                        ? .regular.tint(.white.opacity(0.3))
                        : .regular.tint(.blue),
                    in: .capsule
                )
        }
    }

    // MARK: - Gradient Colors

    private func gradientColors(for page: Int) -> [Color] {
        switch page {
        case 0: return [.blue, .cyan]
        case 1: return [.purple, .blue]
        case 2: return [.orange, .pink]
        case 3: return [.green, .teal]
        case 4: return [.indigo, .purple]
        case 5: return [.cyan, .blue]
        default: return [.blue, .cyan]
        }
    }
}

/// A single onboarding page with an SF Symbol, title, and description
struct OnboardingPage: View {
    let icon: String
    let title: String
    let description: String
    var note: String? = nil

    @State private var isAnimating = false

    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: icon)
                .font(.system(size: 80, weight: .thin))
                .foregroundStyle(.white)
                .scaleEffect(isAnimating ? 1.05 : 0.95)
                .animation(
                    .easeInOut(duration: 2).repeatForever(autoreverses: true),
                    value: isAnimating
                )
                .onAppear { isAnimating = true }

            Text(title)
                .font(.largeTitle.bold())
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)

            Text(description)
                .font(.body)
                .foregroundStyle(.white.opacity(0.85))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)

            if let note {
                Text(note)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.6))
                    .padding(.top, 4)
            }
        }
        .padding()
    }
}
