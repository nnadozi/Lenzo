import SwiftUI

/// Shows all phrases within a selected category, generated on-demand by AI
struct PhraseCategoryDetailView: View {
    @EnvironmentObject var appState: AppState
    let category: PhraseCategory

    @State private var phrases: [Phrase] = []
    @State private var isLoading = true
    @State private var failedCount = 0

    private let translationService = TranslationService()

    var body: some View {
        Group {
            if isLoading {
                loadingView
            } else if phrases.isEmpty {
                emptyView
            } else {
                phraseList
            }
        }
        .navigationTitle(category.rawValue)
        .navigationBarTitleDisplayMode(.large)
        .task {
            await generatePhrases()
        }
    }

    // MARK: - Phrase List

    private var phraseList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(phrases) { phrase in
                    PhraseCardView(phrase: phrase)
                }
            }
            .padding()
        }
    }

    // MARK: - Loading State

    private var loadingView: some View {
        VStack(spacing: 16) {
            Spacer()
            ProgressView()
                .scaleEffect(1.2)
            Text("Generating \(category.rawValue.lowercased()) phrases…")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("\(appState.sourceLanguage.flag) → \(appState.targetLanguage.flag)")
                .font(.caption)
                .foregroundStyle(.tertiary)
            Spacer()
        }
    }

    // MARK: - Empty State

    private var emptyView: some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 40, weight: .thin))
                .foregroundStyle(.secondary)
            Text("Couldn't generate phrases")
                .font(.headline)
            Text("Make sure Apple Intelligence is available and try again.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)

            Button("Retry") {
                isLoading = true
                phrases = []
                Task { await generatePhrases() }
            }
            .glassButton(tint: .blue)

            Spacer()
        }
    }

    // MARK: - AI Generation

    /// Translates all seed phrases for this category using on-device Foundation Models
    private func generatePhrases() async {
        var generated: [Phrase] = []

        for seedPhrase in category.seedPhrases {
            if let result = await translationService.translatePhrase(
                seedPhrase,
                from: appState.sourceLanguage,
                to: appState.targetLanguage
            ) {
                let phrase = Phrase(
                    id: UUID(),
                    category: category,
                    sourcePhrase: seedPhrase,
                    sourceLanguage: appState.sourceLanguage,
                    translatedPhrase: result.translatedPhrase,
                    targetLanguage: appState.targetLanguage,
                    phoneticGuide: result.phoneticGuide,
                    contextNote: result.contextNote
                )
                generated.append(phrase)
            } else {
                failedCount += 1
            }
        }

        phrases = generated
        isLoading = false
    }
}
