import SwiftUI

/// Displays a single phrase with translation, pronunciation, and action buttons
struct PhraseCardView: View {
    @EnvironmentObject var appState: AppState
    let phrase: Phrase

    private let speechService = SpeechService()
    private let haptics = HapticsService()

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Source phrase
            Text(phrase.sourcePhrase)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            // Translated phrase (hero text)
            Text(phrase.translatedPhrase)
                .font(.title3.weight(.semibold))

            // Phonetic pronunciation
            HStack(spacing: 6) {
                Image(systemName: "waveform")
                    .font(.caption)
                    .foregroundStyle(.blue)
                Text(phrase.phoneticGuide)
                    .font(.subheadline)
                    .foregroundStyle(.blue)
                    .italic()
            }

            // Context note
            if !phrase.contextNote.isEmpty {
                Text(phrase.contextNote)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.top, 2)
            }

            // Action buttons
            HStack(spacing: 12) {
                // Speak button
                Button {
                    if appState.hapticsEnabled { haptics.playSaveFeedback() }
                    speechService.speak(phrase.translatedPhrase, in: phrase.targetLanguage)
                } label: {
                    Label("Listen", systemImage: "speaker.wave.2.fill")
                        .font(.caption.weight(.medium))
                }
                .glassButton(tint: .blue)

                Spacer()

                // Bookmark button
                Button {
                    if appState.hapticsEnabled { haptics.playSaveFeedback() }
                    appState.toggleBookmark(for: phrase)
                } label: {
                    Image(systemName: appState.isBookmarked(phrase) ? "bookmark.fill" : "bookmark")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(appState.isBookmarked(phrase) ? .orange : .secondary)
                }
                .glassIconButton()
            }
            .padding(.top, 4)
        }
        .glassCard(cornerRadius: 16)
    }
}
