import SwiftUI

/// Tab 2: Conversation Practice — pick a real-world scenario and practice
/// a back-and-forth conversation with an AI partner in your target language.
struct PhrasesView: View {
    @EnvironmentObject var appState: AppState

    /// The available practice scenarios
    private let scenarios: [(emoji: String, title: String, description: String)] = [
        ("☕", "At a Café", "Order drinks, ask about the menu, and chat with the barista"),
        ("🏨", "Hotel Check-in", "Arrive at a hotel, check in, and ask about amenities"),
        ("🛒", "Grocery Shopping", "Find items, ask about prices, and pay at the register"),
        ("🚕", "Taking a Taxi", "Tell the driver where to go, ask about the fare"),
        ("👋", "Meeting Someone New", "Introduce yourself, make small talk, exchange contacts"),
        ("🏥", "At the Doctor", "Describe symptoms, understand instructions, pick up medicine"),
        ("🗺️", "Asking for Directions", "Find your way around town, understand landmarks"),
        ("🎉", "At a Party", "Mingle, compliment the host, talk about hobbies"),
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Header
                    VStack(spacing: 6) {
                        Text("Practice real conversations in \(appState.targetLanguage.rawValue) \(appState.targetLanguage.flag)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 4)

                    // Scenario cards
                    ForEach(scenarios, id: \.title) { scenario in
                        NavigationLink {
                            ConversationView(
                                scenario: scenario.title,
                                scenarioEmoji: scenario.emoji
                            )
                        } label: {
                            ScenarioCard(
                                emoji: scenario.emoji,
                                title: scenario.title,
                                description: scenario.description,
                                targetLanguage: appState.targetLanguage
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationTitle("Practice")
        }
    }
}

// MARK: - Scenario Card

/// A tappable card representing a conversation scenario the user can practice.
private struct ScenarioCard: View {
    let emoji: String
    let title: String
    let description: String
    let targetLanguage: Language

    var body: some View {
        HStack(spacing: 14) {
            Text(emoji)
                .font(.system(size: 36))

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                Text(description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.tertiary)
        }
        .padding()
        .glassEffect(.regular, in: .rect(cornerRadius: 18))
    }
}

// MARK: - Conversation View

/// The active conversation screen. The AI opens the conversation, the user replies,
/// and the exchange continues naturally. Each AI message shows the target language,
/// a phonetic guide, and the English translation.
struct ConversationView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss

    let scenario: String
    let scenarioEmoji: String

    @State private var messages: [ConvoMessage] = []
    @State private var currentInput = ""
    @State private var isAIResponding = false
    @State private var isStarting = true
    @State private var conversationSession: ConversationSession?

    private let translationService = TranslationService()
    private let speechService = SpeechService()
    private let haptics = HapticsService()

    var body: some View {
        VStack(spacing: 0) {
            // Messages list
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 14) {
                        // Scenario header
                        VStack(spacing: 6) {
                            Text(scenarioEmoji)
                                .font(.system(size: 44))
                            Text(scenario)
                                .font(.headline)
                            Text("Practice with your AI partner in \(appState.targetLanguage.rawValue)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 12)

                        if isStarting {
                            ProgressView("Starting conversation…")
                                .padding(.top, 40)
                        }

                        // Conversation messages
                        ForEach(messages) { msg in
                            ConvoMessageView(
                                message: msg,
                                targetLanguage: appState.targetLanguage,
                                onSpeak: { text in
                                    speechService.speak(text, in: appState.targetLanguage)
                                },
                                onSuggestionTapped: { suggestion in
                                    sendMessage(suggestion)
                                }
                            )
                            .id(msg.id)
                        }

                        // Typing indicator
                        if isAIResponding {
                            HStack {
                                TypingIndicator()
                                Spacer()
                            }
                            .padding(.horizontal, 4)
                            .id("typing")
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 8)
                }
                .onChange(of: messages.count) { _, _ in
                    scrollToBottom(proxy)
                }
                .onChange(of: isAIResponding) { _, responding in
                    if responding { scrollToBottom(proxy) }
                }
            }

            // Input bar
            chatInputBar
        }
        .navigationTitle(scenario)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("New") {
                    restartConversation()
                }
                .font(.subheadline.weight(.medium))
            }
        }
        .task {
            await startConversation()
        }
    }

    // MARK: - Input Bar

    private var chatInputBar: some View {
        HStack(spacing: 10) {
            TextField("Say something…", text: $currentInput)
                .textFieldStyle(.plain)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .glassEffect(.regular, in: .capsule)
                .submitLabel(.send)
                .onSubmit { sendMessage(currentInput) }

            Button {
                sendMessage(currentInput)
            } label: {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(.blue)
            }
            .disabled(currentInput.trimmingCharacters(in: .whitespaces).isEmpty || isAIResponding)
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
    }

    // MARK: - Conversation Logic

    private func startConversation() async {
        let session = translationService.createConversationSession(
            scenario: scenario,
            target: appState.targetLanguage
        )
        conversationSession = session

        guard let turn = await session.startConversation() else {
            isStarting = false
            messages.append(ConvoMessage(
                role: .ai,
                targetText: "Couldn't start the conversation.",
                phoneticGuide: "",
                englishText: "Make sure Apple Intelligence is available and try again.",
                suggestions: []
            ))
            return
        }

        isStarting = false
        messages.append(ConvoMessage(
            role: .ai,
            targetText: turn.targetLanguageText,
            phoneticGuide: turn.phoneticGuide,
            englishText: turn.englishTranslation,
            suggestions: turn.suggestedReplies
        ))

        // Auto-speak the first line
        speechService.speak(turn.targetLanguageText, in: appState.targetLanguage)
    }

    private func sendMessage(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty, !isAIResponding else { return }

        // Add user's message (english translation will be filled in asynchronously)
        let userMsgId = UUID()
        messages.append(ConvoMessage(id: userMsgId, role: .user, targetText: trimmed))
        currentInput = ""
        isAIResponding = true

        if appState.hapticsEnabled { haptics.playSaveFeedback() }

        Task {
            // Translate the user's message to English in the background
            // so "Tap to see English" works on user bubbles too.
            await translateUserMessage(id: userMsgId, text: trimmed)
        }

        Task {
            guard let session = conversationSession,
                  let turn = await session.reply(userMessage: trimmed) else {
                messages.append(ConvoMessage(
                    role: .ai,
                    targetText: "…",
                    phoneticGuide: "",
                    englishText: "I couldn't respond. Try again.",
                    suggestions: []
                ))
                isAIResponding = false
                return
            }

            messages.append(ConvoMessage(
                role: .ai,
                targetText: turn.targetLanguageText,
                phoneticGuide: turn.phoneticGuide,
                englishText: turn.englishTranslation,
                suggestions: turn.suggestedReplies
            ))
            isAIResponding = false

            // Auto-speak the AI's reply
            speechService.speak(turn.targetLanguageText, in: appState.targetLanguage)
        }
    }

    private func restartConversation() {
        messages = []
        isStarting = true
        currentInput = ""
        Task { await startConversation() }
    }

    /// Translates a user message to English and updates the bubble so
    /// the user can tap "Tap to see English" on their own messages.
    private func translateUserMessage(id: UUID, text: String) async {
        let service = TranslationService()
        guard let result = await service.translatePhrase(
            text,
            from: appState.targetLanguage,
            to: appState.sourceLanguage
        ) else { return }

        if let index = messages.firstIndex(where: { $0.id == id }) {
            messages[index].englishText = result.translatedPhrase
        }
    }

    private func scrollToBottom(_ proxy: ScrollViewProxy) {
        withAnimation(.easeOut(duration: 0.3)) {
            if isAIResponding {
                proxy.scrollTo("typing", anchor: .bottom)
            } else if let last = messages.last {
                proxy.scrollTo(last.id, anchor: .bottom)
            }
        }
    }
}

// MARK: - Conversation Message Model

struct ConvoMessage: Identifiable {
    let id: UUID
    let role: Role
    let targetText: String
    var phoneticGuide: String = ""
    var englishText: String = ""
    var suggestions: [String] = []

    /// Convenience initializer that auto-generates an id
    init(id: UUID = UUID(), role: Role, targetText: String, phoneticGuide: String = "", englishText: String = "", suggestions: [String] = []) {
        self.id = id
        self.role = role
        self.targetText = targetText
        self.phoneticGuide = phoneticGuide
        self.englishText = englishText
        self.suggestions = suggestions
    }

    enum Role { case user, ai }
}

// MARK: - Conversation Message Bubble

/// Displays a single message in the conversation.
/// AI messages show: target language (bold) → phonetic → English translation → suggestion chips.
/// User messages show as a simple right-aligned bubble.
private struct ConvoMessageView: View {
    let message: ConvoMessage
    let targetLanguage: Language
    let onSpeak: (String) -> Void
    let onSuggestionTapped: (String) -> Void

    @State private var showTranslation = false

    var body: some View {
        if message.role == .user {
            userBubble
        } else {
            aiBubble
        }
    }

    // MARK: User bubble

    private var userBubble: some View {
        HStack {
            Spacer(minLength: 60)
            VStack(alignment: .trailing, spacing: 6) {
                Text(message.targetText)
                    .font(.subheadline)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .glassEffect(.regular.tint(.blue.opacity(0.2)), in: .rect(cornerRadius: 18))

                // Show "Tap to see English" if an English translation is available
                if !message.englishText.isEmpty {
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            showTranslation.toggle()
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: showTranslation ? "eye.fill" : "eye.slash")
                                .font(.caption2)
                            Text(showTranslation ? message.englishText : "Tap to see English")
                                .font(.caption)
                        }
                        .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                    .padding(.trailing, 4)
                }
            }
        }
    }

    // MARK: AI bubble

    private var aiBubble: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 8) {
                // Target language text (main content)
                Text(message.targetText)
                    .font(.body.weight(.medium))

                // Phonetic guide
                if !message.phoneticGuide.isEmpty {
                    Text(message.phoneticGuide)
                        .font(.caption)
                        .foregroundStyle(.blue)
                        .italic()
                }

                // Tap to reveal English translation
                if !message.englishText.isEmpty {
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            showTranslation.toggle()
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: showTranslation ? "eye.fill" : "eye.slash")
                                .font(.caption2)
                            Text(showTranslation ? message.englishText : "Tap to see English")
                                .font(.caption)
                        }
                        .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                }

                // Action row: speak button
                Button {
                    onSpeak(message.targetText)
                } label: {
                    Image(systemName: "speaker.wave.2.fill")
                        .font(.caption)
                        .foregroundStyle(.blue)
                }
                .buttonStyle(.plain)

                // Suggested replies
                if !message.suggestions.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("You could say:")
                            .font(.caption2)
                            .foregroundStyle(.tertiary)

                        ForEach(message.suggestions, id: \.self) { suggestion in
                            Button {
                                onSuggestionTapped(suggestion)
                            } label: {
                                Text(suggestion)
                                    .font(.caption)
                                    .foregroundStyle(.primary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(
                                        Capsule()
                                            .strokeBorder(Color.blue.opacity(0.5), lineWidth: 1.5)
                                            .background(Capsule().fill(Color.blue.opacity(0.08)))
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.top, 4)
                }
            }
            .padding(12)
            .glassEffect(.regular, in: .rect(cornerRadius: 18))

            Spacer(minLength: 40)
        }
    }
}

// MARK: - Typing Indicator

private struct TypingIndicator: View {
    @State private var animate = false

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .fill(.secondary)
                    .frame(width: 6, height: 6)
                    .offset(y: animate ? -4 : 0)
                    .animation(
                        .easeInOut(duration: 0.4)
                        .repeatForever(autoreverses: true)
                        .delay(Double(i) * 0.15),
                        value: animate
                    )
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .glassEffect(.regular, in: .capsule)
        .onAppear { animate = true }
    }
}
