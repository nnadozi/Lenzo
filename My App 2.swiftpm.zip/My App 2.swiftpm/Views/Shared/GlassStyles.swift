import SwiftUI

// MARK: - Reusable Liquid Glass View Modifiers

/// Standard glass card with rounded corners
struct GlassCard: ViewModifier {
    var cornerRadius: CGFloat = 20

    func body(content: Content) -> some View {
        content
            .padding()
            .glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
    }
}

/// Tinted glass button (capsule shape)
struct GlassButton: ViewModifier {
    var color: Color = .blue

    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .glassEffect(.regular.tint(color), in: .capsule)
    }
}

/// Circular glass icon button
struct GlassIconButton: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.system(size: 16, weight: .semibold))
            .frame(width: 44, height: 44)
            .glassEffect(.regular, in: .circle)
    }
}

// MARK: - View Extensions

extension View {
    func glassCard(cornerRadius: CGFloat = 20) -> some View {
        modifier(GlassCard(cornerRadius: cornerRadius))
    }

    func glassButton(tint: Color = .blue) -> some View {
        modifier(GlassButton(color: tint))
    }

    func glassIconButton() -> some View {
        modifier(GlassIconButton())
    }
}
