import SwiftUI

/// Displays a captured/lifted subject image.
/// Lifted subjects (with transparent backgrounds) get a drop shadow to create
/// the "popped off the screen" look. Full-frame images get rounded corners.
struct LiftedImageView: View {
    let imageData: Data
    var maxHeight: CGFloat = 200

    var body: some View {
        if let uiImage = UIImage(data: imageData) {
            let hasTransparency = imageData.starts(with: [0x89, 0x50, 0x4E, 0x47]) // PNG marker

            Image(uiImage: uiImage)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: maxHeight)
                .if(!hasTransparency) { view in
                    view.clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .shadow(color: .black.opacity(hasTransparency ? 0.35 : 0.15), radius: hasTransparency ? 16 : 8, y: hasTransparency ? 8 : 4)
        } else {
            // Placeholder when image can't be decoded
            Image(systemName: "photo")
                .font(.system(size: 60))
                .foregroundStyle(.secondary)
                .frame(maxHeight: maxHeight)
        }
    }
}

// MARK: - Conditional Modifier Helper

private extension View {
    /// Applies a transformation only when a condition is true.
    @ViewBuilder
    func `if`<Transform: View>(_ condition: Bool, transform: (Self) -> Transform) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}
