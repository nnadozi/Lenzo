import SwiftUI

/// Sheet showing available practice games for a word list
struct GamePickerSheet: View {
    @Environment(\.dismiss) private var dismiss
    let wordList: WordList

    @State private var selectedGame: GameType?

    enum GameType: String, Identifiable {
        case flashcards = "Flashcards"
        case memoryMatch = "Memory Match"
        case quiz = "Quiz"
        case wordScramble = "Word Scramble"

        var id: String { rawValue }

        var icon: String {
            switch self {
            case .flashcards: return "rectangle.on.rectangle.angled"
            case .memoryMatch: return "brain.head.profile"
            case .quiz: return "checkmark.circle"
            case .wordScramble: return "textformat.abc"
            }
        }

        var description: String {
            switch self {
            case .flashcards: return "Flip cards to test your memory"
            case .memoryMatch: return "Match images with translations"
            case .quiz: return "Multiple choice challenge"
            case .wordScramble: return "Unscramble the letters to spell the word"
            }
        }

        var minItems: Int {
            switch self {
            case .flashcards: return 3
            case .memoryMatch: return 3
            case .quiz: return 3
            case .wordScramble: return 2
            }
        }
    }

    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Choose a Game")
                    .font(.title2.weight(.bold))
                    .padding(.top)

                GlassEffectContainer {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach([GameType.flashcards, .memoryMatch, .quiz, .wordScramble]) { game in
                            let disabled = wordList.itemCount < game.minItems

                            Button {
                                selectedGame = game
                            } label: {
                                VStack(spacing: 10) {
                                    Image(systemName: game.icon)
                                        .font(.system(size: 28))
                                        .foregroundStyle(disabled ? .secondary : .primary)

                                    Text(game.rawValue)
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(disabled ? .secondary : .primary)

                                    Text(game.description)
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                        .multilineTextAlignment(.center)
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                .frame(maxWidth: .infinity, minHeight: 110)
                                .padding(.vertical, 16)
                                .padding(.horizontal, 8)
                                .glassEffect(.regular, in: .rect(cornerRadius: 16))
                            }
                            .buttonStyle(.plain)
                            .disabled(disabled)
                        }
                    }
                }
                .padding(.horizontal)

                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .fullScreenCover(item: $selectedGame) { game in
                gameView(for: game)
            }
        }
    }

    @ViewBuilder
    private func gameView(for game: GameType) -> some View {
        switch game {
        case .flashcards:
            FlashcardsView(wordList: wordList)
        case .memoryMatch:
            MemoryMatchView(wordList: wordList)
        case .quiz:
            QuizView(wordList: wordList)
        case .wordScramble:
            WordScrambleView(wordList: wordList)
        }
    }
}
