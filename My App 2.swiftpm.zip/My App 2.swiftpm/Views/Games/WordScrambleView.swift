import SwiftUI

/// Wordle-style game: guess the target translation with color-coded letter feedback.
/// Green = right letter, right spot. Yellow = right letter, wrong spot. Gray = not in word.
struct WordScrambleView: View {
    @Environment(\.dismiss) private var dismiss
    let wordList: WordList

    private let maxGuesses = 6

    @State private var items: [VocabItem] = []
    @State private var currentItemIndex = 0
    @State private var target: [Character] = []

    // Each submitted guess + its colors
    @State private var submittedGuesses: [[Character]] = []
    @State private var submittedColors: [[LetterColor]] = []

    // The row currently being typed
    @State private var currentInput: [Character] = []

    // Best color per key for the on-screen keyboard
    @State private var keyColors: [Character: LetterColor] = [:]

    @State private var score = 0
    @State private var roundOver = false   // won or lost current word
    @State private var shake = false
    @State private var gameOver = false    // all words done

    private let haptics = HapticsService()

    // MARK: - Body

    var body: some View {
        NavigationStack {
            Group {
                if items.isEmpty {
                    ProgressView("Loading words...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if gameOver {
                    completionView
                } else {
                    wordleView
                }
            }
            .navigationTitle("Word Scramble")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
        .onAppear { buildGame() }
    }

    // MARK: - Wordle View

    private var wordleView: some View {
        VStack(spacing: 12) {
            // Progress + score
            HStack {
                Text("Word \(currentItemIndex + 1) of \(items.count)")
                    .font(.subheadline).foregroundStyle(.secondary)
                Spacer()
                Text("Score: \(score)")
                    .font(.subheadline.weight(.medium))
            }
            .padding(.horizontal)

            // Image + English hint
            if currentItemIndex < items.count {
                let item = items[currentItemIndex]
                VStack(spacing: 4) {
                    LiftedImageView(imageData: item.capturedImageData, maxHeight: 100)
                    Text(item.englishWord.capitalized)
                        .font(.headline)
                    Text("in \(item.targetLanguage.rawValue)")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }

            // Guess grid
            guessGrid
                .offset(x: shake ? -6 : 0)
                .animation(
                    shake ? .easeInOut(duration: 0.06).repeatCount(4, autoreverses: true) : .default,
                    value: shake
                )

            Spacer(minLength: 0)

            // Revealed answer or "Next word" when round is over
            if roundOver {
                VStack(spacing: 10) {
                    if !submittedGuesses.contains(where: { String($0) == String(target) }) {
                        Text("The answer was: \(String(target).uppercased())")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    Button(currentItemIndex + 1 < items.count ? "Next Word →" : "See Results") {
                        advanceWord()
                    }
                    .glassButton(tint: .blue)
                }
                .padding(.bottom, 8)
            } else {
                // On-screen letter keyboard
                keyboard
                    .padding(.bottom, 8)
            }
        }
        .padding(.top, 8)
    }

    // MARK: - Guess Grid

    private var guessGrid: some View {
        let tileSize: CGFloat = target.count <= 6 ? 46 : target.count <= 8 ? 38 : 32

        return VStack(spacing: 5) {
            ForEach(0..<maxGuesses, id: \.self) { row in
                HStack(spacing: 5) {
                    ForEach(0..<target.count, id: \.self) { col in
                        tileView(row: row, col: col, size: tileSize)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func tileView(row: Int, col: Int, size: CGFloat) -> some View {
        let isSubmitted = row < submittedGuesses.count
        let isCurrentRow = row == submittedGuesses.count

        let letter: Character? = {
            if isSubmitted { return submittedGuesses[row][safe: col] }
            if isCurrentRow { return currentInput[safe: col] }
            return nil
        }()

        let color: Color = {
            guard isSubmitted, let c = submittedColors[row][safe: col] else { return .clear }
            return c.fillColor
        }()

        let borderColor: Color = {
            if isSubmitted { return .clear }
            if isCurrentRow && letter != nil { return .primary.opacity(0.5) }
            return Color(.systemGray4)
        }()

        ZStack {
            RoundedRectangle(cornerRadius: 6)
                .fill(isSubmitted ? color : Color(.systemGray6))
                .frame(width: size, height: size)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(borderColor, lineWidth: 1.5)
                )

            if let char = letter {
                Text(String(char).uppercased())
                    .font(.system(size: size * 0.45, weight: .bold))
                    .foregroundStyle(isSubmitted ? .white : .primary)
            }
        }
    }

    // MARK: - Keyboard

    private let keyboardRows: [[Character]] = [
        Array("qwertyuiop"),
        Array("asdfghjkl"),
        Array("zxcvbnm")
    ]

    private var keyboard: some View {
        VStack(spacing: 6) {
            ForEach(keyboardRows.indices, id: \.self) { row in
                HStack(spacing: 5) {
                    if row == 2 {
                        // Delete key
                        Button { deleteLetter() } label: {
                            Image(systemName: "delete.backward")
                                .font(.system(size: 14, weight: .medium))
                                .frame(width: 42, height: 40)
                                .background(RoundedRectangle(cornerRadius: 6).fill(Color(.systemGray3)))
                                .foregroundStyle(.primary)
                        }
                        .buttonStyle(.plain)
                    }

                    ForEach(keyboardRows[row], id: \.self) { key in
                        keyButton(key)
                    }

                    if row == 2 {
                        // Submit key
                        Button { submitGuess() } label: {
                            Text("GO")
                                .font(.system(size: 12, weight: .bold))
                                .frame(width: 42, height: 40)
                                .background(
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(currentInput.count == target.count ? Color.blue : Color(.systemGray3))
                                )
                                .foregroundStyle(.white)
                        }
                        .buttonStyle(.plain)
                        .disabled(currentInput.count != target.count)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func keyButton(_ key: Character) -> some View {
        let color = keyColors[key]?.fillColor ?? Color(.systemGray3)
        let textColor: Color = keyColors[key] != nil ? .white : .primary

        Button { typeLetter(key) } label: {
            Text(String(key).uppercased())
                .font(.system(size: 14, weight: .semibold))
                .frame(width: 30, height: 40)
                .background(RoundedRectangle(cornerRadius: 6).fill(color))
                .foregroundStyle(textColor)
        }
        .buttonStyle(.plain)
        .disabled(roundOver)
    }

    // MARK: - Completion

    private var completionView: some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: score > items.count / 2 ? "star.fill" : "arrow.counterclockwise")
                .font(.system(size: 50))
                .foregroundStyle(score > items.count / 2 ? .yellow : .orange)
            Text(score > items.count / 2 ? "Well done!" : "Keep it up!")
                .font(.title.bold())
            Text("You got \(score) out of \(items.count)")
                .font(.subheadline).foregroundStyle(.secondary)
            HStack(spacing: 16) {
                Button("Play Again") { buildGame() }
                    .glassButton(tint: .blue)
                Button("Close") { dismiss() }
                    .glassButton(tint: .secondary)
            }
            Spacer()
        }
    }

    // MARK: - Input Logic

    private func typeLetter(_ char: Character) {
        guard currentInput.count < target.count, !roundOver else { return }
        currentInput.append(char)
        haptics.playSaveFeedback()
    }

    private func deleteLetter() {
        guard !currentInput.isEmpty else { return }
        currentInput.removeLast()
        haptics.playSaveFeedback()
    }

    private func submitGuess() {
        guard currentInput.count == target.count, !roundOver else { return }

        let guess = currentInput
        let colors = evaluate(guess: guess, target: target)

        submittedGuesses.append(guess)
        submittedColors.append(colors)

        // Update keyboard colors (green > yellow > gray)
        for (char, color) in zip(guess, colors) {
            let existing = keyColors[char]
            if existing == nil || color.priority > existing!.priority {
                keyColors[char] = color
            }
        }

        let won = colors.allSatisfy { $0 == .correct }
        if won {
            score += 1
            haptics.playCorrectFeedback()
            roundOver = true
        } else if submittedGuesses.count >= maxGuesses {
            haptics.playIncorrectFeedback()
            roundOver = true
        } else {
            // Wrong guess — shake and clear input
            shake = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) { shake = false }
            haptics.playIncorrectFeedback()
        }

        currentInput = []
    }

    // MARK: - Wordle Evaluation

    /// Returns a color result for each letter in the guess against the target.
    private func evaluate(guess: [Character], target: [Character]) -> [LetterColor] {
        var result = Array(repeating: LetterColor.absent, count: guess.count)
        var targetCounts: [Character: Int] = [:]

        // First pass: mark correct (green) positions
        for i in guess.indices {
            if guess[i] == target[i] {
                result[i] = .correct
            } else {
                targetCounts[target[i], default: 0] += 1
            }
        }

        // Second pass: mark misplaced (yellow)
        for i in guess.indices where result[i] != .correct {
            let ch = guess[i]
            if let count = targetCounts[ch], count > 0 {
                result[i] = .misplaced
                targetCounts[ch] = count - 1
            }
        }

        return result
    }

    // MARK: - Round / Game Management

    private func advanceWord() {
        let nextIndex = currentItemIndex + 1
        if nextIndex >= items.count {
            gameOver = true
        } else {
            currentItemIndex = nextIndex
            loadCurrentWord()
        }
    }

    private func loadCurrentWord() {
        let raw = items[currentItemIndex].targetWord.lowercased().filter { $0.isLetter }
        target = Array(raw)
        submittedGuesses = []
        submittedColors = []
        currentInput = []
        keyColors = [:]
        roundOver = false
    }

    private func buildGame() {
        // Filter to words with at least 3 letters, then take up to 6
        items = Array(
            wordList.items
                .filter { $0.targetWord.filter(\.isLetter).count >= 3 }
                .shuffled()
                .prefix(6)
        )
        currentItemIndex = 0
        score = 0
        gameOver = false

        guard !items.isEmpty else {
            // No playable words — skip straight to results
            gameOver = true
            return
        }
        loadCurrentWord()
    }
}

// MARK: - Letter Color

enum LetterColor: Equatable {
    case correct, misplaced, absent

    var fillColor: Color {
        switch self {
        case .correct:  return .green
        case .misplaced: return .orange
        case .absent:   return Color(.systemGray)
        }
    }

    /// Priority used to keep the best color on keyboard keys
    var priority: Int {
        switch self {
        case .correct: return 2
        case .misplaced: return 1
        case .absent: return 0
        }
    }
}

// MARK: - Safe Subscript

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
