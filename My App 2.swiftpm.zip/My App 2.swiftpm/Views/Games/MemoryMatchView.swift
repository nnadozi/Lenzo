import SwiftUI

/// Memory match game: grid of face-down cards — match object images with their translations
struct MemoryMatchView: View {
    @Environment(\.dismiss) private var dismiss
    let wordList: WordList

    @State private var cards: [MemoryCard] = []
    @State private var firstFlipped: Int?
    @State private var secondFlipped: Int?
    @State private var matchedPairs = 0
    @State private var moves = 0
    @State private var isChecking = false
    @State private var totalPairs = 0

    private let haptics = HapticsService()

    private var columns: [GridItem] {
        let count = totalPairs <= 4 ? 3 : 4
        return Array(repeating: GridItem(.flexible(), spacing: 8), count: count)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                // Stats header
                HStack {
                    Label("\(moves) moves", systemImage: "hand.tap")
                    Spacer()
                    Label("\(matchedPairs)/\(totalPairs) pairs", systemImage: "checkmark.circle")
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .padding(.horizontal)

                // Card grid
                if matchedPairs == totalPairs && totalPairs > 0 {
                    completionView
                } else {
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 8) {
                            ForEach(cards.indices, id: \.self) { index in
                                memoryCardView(at: index)
                            }
                        }
                        .padding()
                    }
                }

                Spacer()
            }
            .navigationTitle("Memory Match")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
        .onAppear { setupGame() }
    }

    // MARK: - Card View

    @ViewBuilder
    private func memoryCardView(at index: Int) -> some View {
        let card = cards[index]

        Button {
            flipCard(at: index)
        } label: {
            Group {
                if card.isFaceUp || card.isMatched {
                    // Revealed card content
                    VStack(spacing: 4) {
                        switch card.content {
                        case .image(let data):
                            if let img = UIImage(data: data) {
                                Image(uiImage: img)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 50)
                            }
                        case .word(let text):
                            Text(text)
                                .font(.subheadline.weight(.semibold))
                                .multilineTextAlignment(.center)
                                .minimumScaleFactor(0.7)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 80)
                    .glassEffect(
                        card.isMatched
                            ? .regular.tint(.green.opacity(0.3))
                            : .regular,
                        in: .rect(cornerRadius: 12)
                    )
                    .opacity(card.isMatched ? 0.7 : 1.0)
                } else {
                    // Face-down card
                    ZStack {
                        Image(systemName: "questionmark")
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 80)
                    .glassEffect(.regular, in: .rect(cornerRadius: 12))
                }
            }
        }
        .buttonStyle(.plain)
        .disabled(card.isFaceUp || card.isMatched || isChecking)
    }

    // MARK: - Completion

    private var completionView: some View {
        VStack(spacing: 16) {
            Spacer()

            Image(systemName: "trophy.fill")
                .font(.system(size: 60))
                .foregroundStyle(.yellow)

            Text("You Win!")
                .font(.title.bold())

            Text("Completed in \(moves) moves")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Button("Play Again") {
                setupGame()
            }
            .glassButton(tint: .blue)

            Spacer()
        }
    }

    // MARK: - Game Logic

    private func setupGame() {
        let pairCount = min(6, wordList.items.count)
        totalPairs = pairCount
        matchedPairs = 0
        moves = 0
        firstFlipped = nil
        secondFlipped = nil

        let selectedItems = Array(wordList.items.shuffled().prefix(pairCount))

        var newCards: [MemoryCard] = []
        for item in selectedItems {
            // Image card
            newCards.append(MemoryCard(
                pairId: item.id,
                content: .image(item.capturedImageData)
            ))
            // Word card
            newCards.append(MemoryCard(
                pairId: item.id,
                content: .word(item.targetWord)
            ))
        }

        cards = newCards.shuffled()
    }

    private func flipCard(at index: Int) {
        guard !cards[index].isFaceUp, !cards[index].isMatched else { return }

        cards[index].isFaceUp = true
        haptics.playFlipFeedback()

        if firstFlipped == nil {
            firstFlipped = index
        } else if secondFlipped == nil {
            secondFlipped = index
            moves += 1
            isChecking = true
            checkMatch()
        }
    }

    private func checkMatch() {
        guard let first = firstFlipped, let second = secondFlipped else { return }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            if cards[first].pairId == cards[second].pairId {
                cards[first].isMatched = true
                cards[second].isMatched = true
                matchedPairs += 1
                haptics.playCorrectFeedback()
            } else {
                cards[first].isFaceUp = false
                cards[second].isFaceUp = false
                haptics.playIncorrectFeedback()
            }

            firstFlipped = nil
            secondFlipped = nil
            isChecking = false
        }
    }
}

// MARK: - Memory Card Model

struct MemoryCard: Identifiable {
    let id = UUID()
    let pairId: UUID
    let content: CardContent
    var isFaceUp = false
    var isMatched = false

    enum CardContent {
        case image(Data)
        case word(String)
    }
}
