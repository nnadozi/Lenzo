import SwiftUI

/// Sentence builder game: fill-in-the-blank sentences using captured vocabulary
struct SentenceBuilderView: View {
    @Environment(\.dismiss) private var dismiss
    let wordList: WordList

    @State private var exercises: [SentenceExercise] = []
    @State private var currentIndex = 0
    @State private var selectedWord: String?
    @State private var typedAnswer = ""
    @State private var hasAnswered = false
    @State private var isCorrect = false
    @State private var score = 0
    @State private var isLoading = true

    private let haptics = HapticsService()

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                if isLoading {
                    ProgressView("Generating sentences...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if currentIndex < exercises.count {
                    exerciseView(for: exercises[currentIndex])
                } else {
                    completionView
                }
            }
            .navigationTitle("Sentence Builder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
        .task {
            await generateExercises()
        }
    }

    // MARK: - Exercise View

    @ViewBuilder
    private func exerciseView(for exercise: SentenceExercise) -> some View {
        HStack {
            Text("Question \(currentIndex + 1) of \(exercises.count)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Spacer()
            Text("Score: \(score)")
                .font(.subheadline.weight(.medium))
        }
        .padding(.horizontal)

        // Object image
        LiftedImageView(imageData: exercise.imageData, maxHeight: 120)

        // Sentence with blank
        VStack(spacing: 12) {
            Text(exercise.sentenceWithBlank)
                .font(.title3.weight(.medium))
                .multilineTextAlignment(.center)

            Text(exercise.englishHint)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .italic()
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 24)
        .glassCard(cornerRadius: 16)
        .padding(.horizontal)

        // Word options
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(exercise.options, id: \.self) { option in
                    Button {
                        checkAnswer(option, exercise: exercise)
                    } label: {
                        sentenceOptionLabel(option: option, exercise: exercise)
                    }
                    .buttonStyle(.plain)
                    .disabled(hasAnswered)
                }
            }
            .padding(.horizontal)
        }

        // Or type answer
        if !hasAnswered {
            HStack {
                TextField("Or type your answer...", text: $typedAnswer)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled()

                Button("Check") {
                    checkAnswer(typedAnswer.trimmingCharacters(in: .whitespaces), exercise: exercise)
                }
                .disabled(typedAnswer.trimmingCharacters(in: .whitespaces).isEmpty)
                .glassButton(tint: .blue)
            }
            .padding(.horizontal)
        }

        // Feedback
        if hasAnswered {
            HStack {
                Image(systemName: isCorrect ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .foregroundStyle(isCorrect ? .green : .red)
                Text(isCorrect ? "Correct!" : "The answer is: \(exercise.answer)")
                    .font(.headline)
            }
            .padding()
            .transition(.scale.combined(with: .opacity))
        }

        Spacer()
    }

    // MARK: - Completion

    private var completionView: some View {
        VStack(spacing: 16) {
            Spacer()

            Image(systemName: "text.badge.checkmark")
                .font(.system(size: 50))
                .foregroundStyle(.green)

            Text("Sentences Complete!")
                .font(.title.bold())

            Text("Score: \(score)/\(exercises.count)")
                .font(.title3)
                .foregroundStyle(.secondary)

            Button("Close") { dismiss() }
                .glassButton(tint: .blue)

            Spacer()
        }
    }

    // MARK: - Logic

    private func checkAnswer(_ answer: String, exercise: SentenceExercise) {
        guard !hasAnswered else { return }
        hasAnswered = true
        selectedWord = answer

        // Case-insensitive comparison
        isCorrect = answer.lowercased() == exercise.answer.lowercased()

        if isCorrect {
            score += 1
            haptics.playCorrectFeedback()
        } else {
            haptics.playIncorrectFeedback()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation {
                currentIndex += 1
                hasAnswered = false
                isCorrect = false
                selectedWord = nil
                typedAnswer = ""
            }
        }
    }

    @ViewBuilder
    private func sentenceOptionLabel(option: String, exercise: SentenceExercise) -> some View {
        let base = Text(option)
            .font(.subheadline.weight(.medium))
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

        if hasAnswered && option.lowercased() == exercise.answer.lowercased() {
            base.glassEffect(.regular.tint(.green), in: .capsule)
        } else if hasAnswered && option == selectedWord {
            base.glassEffect(.regular.tint(.red), in: .capsule)
        } else {
            base.glassEffect(.regular, in: .capsule)
        }
    }

    private func generateExercises() async {
        let items = Array(wordList.items.shuffled().prefix(8))
        let service = TranslationService()

        var generated: [SentenceExercise] = []

        for item in items {
            if let fillIn = await service.generateFillInBlank(for: item.targetWord, in: item.targetLanguage) {
                // Create distractor options from other words in the list
                let distractors = wordList.items
                    .filter { $0.id != item.id }
                    .prefix(2)
                    .map { $0.targetWord }

                let allOptions = ([fillIn.answer] + distractors).shuffled()

                generated.append(SentenceExercise(
                    imageData: item.capturedImageData,
                    sentenceWithBlank: fillIn.sentenceWithBlank,
                    englishHint: fillIn.englishHint,
                    answer: fillIn.answer,
                    options: allOptions
                ))
            }
        }

        // Fallback: if AI couldn't generate sentences, create simple ones
        if generated.isEmpty {
            for item in items.prefix(5) {
                generated.append(SentenceExercise(
                    imageData: item.capturedImageData,
                    sentenceWithBlank: "______ ?",
                    englishHint: "What is \"\(item.sourceWord)\" in \(item.targetLanguage.rawValue)?",
                    answer: item.targetWord,
                    options: [item.targetWord]
                ))
            }
        }

        await MainActor.run {
            exercises = generated
            isLoading = false
        }
    }
}

struct SentenceExercise {
    let imageData: Data
    let sentenceWithBlank: String
    let englishHint: String
    let answer: String
    let options: [String]
}
