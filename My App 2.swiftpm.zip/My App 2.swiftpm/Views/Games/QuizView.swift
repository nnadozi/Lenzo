import SwiftUI

/// Multiple choice quiz: show an object image and pick the correct translation from 4 options
struct QuizView: View {
    @Environment(\.dismiss) private var dismiss
    let wordList: WordList

    @State private var questions: [QuizQuestion] = []
    @State private var currentIndex = 0
    @State private var score = 0
    @State private var streak = 0
    @State private var bestStreak = 0
    @State private var selectedAnswer: String?
    @State private var hasAnswered = false
    @State private var isLoading = true

    private let haptics = HapticsService()

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                if isLoading {
                    ProgressView("Generating quiz...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if currentIndex < questions.count {
                    questionView(for: questions[currentIndex])
                } else {
                    completionView
                }
            }
            .navigationTitle("Quiz")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
        .task {
            await generateQuestions()
        }
    }

    // MARK: - Question View

    @ViewBuilder
    private func questionView(for question: QuizQuestion) -> some View {
        HStack {
            Text("Question \(currentIndex + 1) of \(questions.count)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Spacer()
            HStack(spacing: 4) {
                Text("Score: \(score)/\(currentIndex)")
                if streak > 1 {
                    Text("🔥 \(streak)")
                }
            }
            .font(.subheadline.weight(.medium))
        }
        .padding(.horizontal)

        Spacer()

        LiftedImageView(imageData: question.imageData, maxHeight: 140)

        Text("What is this called in \(question.targetLanguage.rawValue)?")
            .font(.headline)
            .multilineTextAlignment(.center)
            .padding(.horizontal)

        Spacer()

        // Answer options — using simple backgrounds instead of glassEffect to avoid tap issues
        VStack(spacing: 12) {
            ForEach(Array(question.options.enumerated()), id: \.offset) { index, option in
                Button {
                    selectAnswer(option, correctAnswer: question.correctAnswer)
                } label: {
                    Text(option)
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(optionBackground(for: option, correctAnswer: question.correctAnswer))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(optionBorder(for: option, correctAnswer: question.correctAnswer), lineWidth: 2)
                        )
                }
                .buttonStyle(.plain)
                .disabled(hasAnswered)
            }
        }
        .padding(.horizontal)

        Spacer()
    }

    // MARK: - Option Colors

    private func optionBackground(for option: String, correctAnswer: String) -> Color {
        guard hasAnswered else { return Color(.systemGray6) }
        if option == correctAnswer { return .green.opacity(0.2) }
        if option == selectedAnswer { return .red.opacity(0.2) }
        return Color(.systemGray6)
    }

    private func optionBorder(for option: String, correctAnswer: String) -> Color {
        guard hasAnswered else { return .clear }
        if option == correctAnswer { return .green }
        if option == selectedAnswer { return .red }
        return .clear
    }

    // MARK: - Completion

    private var completionView: some View {
        VStack(spacing: 16) {
            Spacer()

            Image(systemName: score > questions.count / 2 ? "star.fill" : "arrow.counterclockwise")
                .font(.system(size: 50))
                .foregroundStyle(score > questions.count / 2 ? .yellow : .orange)

            Text(score > questions.count / 2 ? "Great Job!" : "Keep Practicing!")
                .font(.title.bold())

            Text("You got \(score) out of \(questions.count) correct")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if bestStreak > 1 {
                Text("Best streak: \(bestStreak) 🔥")
                    .font(.subheadline)
            }

            HStack(spacing: 16) {
                Button("Play Again") {
                    Task { await resetAndRegenerate() }
                }
                .glassButton(tint: .blue)

                Button("Close") { dismiss() }
                    .glassButton(tint: .secondary)
            }

            Spacer()
        }
    }

    // MARK: - Logic

    private func selectAnswer(_ answer: String, correctAnswer: String) {
        guard !hasAnswered else { return }
        selectedAnswer = answer
        hasAnswered = true

        if answer == correctAnswer {
            score += 1
            streak += 1
            bestStreak = max(bestStreak, streak)
            haptics.playCorrectFeedback()
        } else {
            streak = 0
            haptics.playIncorrectFeedback()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            withAnimation {
                currentIndex += 1
                selectedAnswer = nil
                hasAnswered = false
            }
        }
    }

    private func generateQuestions() async {
        let items = Array(wordList.items.shuffled().prefix(10))
        let service = TranslationService()

        var generated: [QuizQuestion] = []

        for item in items {
            var distractors = await service.generateDistractors(
                for: item.englishWord,
                in: item.targetLanguage,
                count: 3
            )

            // Remove any distractor that duplicates the correct answer (case-insensitive)
            distractors = distractors.filter {
                $0.lowercased() != item.targetWord.lowercased()
            }

            // Deduplicate distractors among themselves, keeping order
            var seen = Set<String>()
            distractors = distractors.filter { seen.insert($0.lowercased()).inserted }

            // Pad with other words from the list if AI returned too few distractors
            if distractors.count < 3 {
                let extras = wordList.items
                    .map(\.targetWord)
                    .filter { $0.lowercased() != item.targetWord.lowercased() && !seen.contains($0.lowercased()) }
                    .shuffled()
                    .prefix(3 - distractors.count)
                distractors += extras
            }

            let allOptions = ([item.targetWord] + distractors).shuffled()

            generated.append(QuizQuestion(
                imageData: item.capturedImageData,
                sourceWord: item.sourceWord,
                correctAnswer: item.targetWord,
                options: allOptions,
                targetLanguage: item.targetLanguage
            ))
        }

        await MainActor.run {
            questions = generated
            isLoading = false
        }
    }

    private func resetAndRegenerate() async {
        await MainActor.run {
            isLoading = true
            currentIndex = 0
            score = 0
            streak = 0
            bestStreak = 0
        }
        await generateQuestions()
    }
}

struct QuizQuestion {
    let imageData: Data
    let sourceWord: String
    let correctAnswer: String
    let options: [String]
    let targetLanguage: Language
}
