import SwiftUI

/// Flashcard game: shows object image + source word, tap to flip and reveal translation
struct FlashcardsView: View {
    @Environment(\.dismiss) private var dismiss
    let wordList: WordList

    @State private var deck: [VocabItem] = []
    @State private var currentIndex = 0
    @State private var isFlipped = false
    @State private var hardCount = 0
    @State private var gotItCount = 0

    private let haptics = HapticsService()
    private let speech = SpeechService()

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Progress header
                HStack {
                    Text("Card \(currentIndex + 1) of \(deck.count)")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(.horizontal)

                Spacer()

                // Flashcard
                if currentIndex < deck.count {
                    flashcard(for: deck[currentIndex])
                        .onTapGesture {
                            withAnimation(.spring(response: 0.6)) {
                                isFlipped.toggle()
                                haptics.playFlipFeedback()
                            }
                        }
                } else {
                    completionView
                }

                Spacer()

                // Assessment buttons (shown only when flipped)
                if isFlipped && currentIndex < deck.count {
                    HStack(spacing: 20) {
                        Button {
                            markHard()
                        } label: {
                            Label("Hard", systemImage: "arrow.counterclockwise")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                        }
                        .glassButton(tint: .orange)

                        Button {
                            markGotIt()
                        } label: {
                            Label("Got it!", systemImage: "checkmark")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                        }
                        .glassButton(tint: .green)
                    }
                    .padding(.horizontal)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                // Progress bar
                ProgressView(value: Double(gotItCount), total: Double(max(deck.count, 1)))
                    .tint(.green)
                    .padding(.horizontal)
                    .padding(.bottom, 8)
            }
            .padding(.vertical)
            .navigationTitle("Flashcards")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
        .onAppear {
            deck = wordList.items.shuffled()
        }
    }

    // MARK: - Flashcard View

    @ViewBuilder
    private func flashcard(for item: VocabItem) -> some View {
        ZStack {
            // Front of card
            VStack(spacing: 16) {
                LiftedImageView(imageData: item.capturedImageData, maxHeight: 150)
                Text(item.sourceWord)
                    .font(.title.weight(.semibold))
                if !isFlipped {
                    Text("Tap to reveal")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .opacity(isFlipped ? 0 : 1)
            .rotation3DEffect(.degrees(isFlipped ? 180 : 0), axis: (x: 0, y: 1, z: 0))

            // Back of card
            VStack(spacing: 12) {
                Text(item.targetWord)
                    .font(.largeTitle.bold())

                Text("/\(item.phoneticGuide)/")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .italic()

                Button {
                    speech.speak(item.targetWord, in: item.targetLanguage)
                } label: {
                    Image(systemName: "speaker.wave.2.fill")
                        .foregroundStyle(.blue)
                }
                .glassIconButton()

                if item.mnemonic != "—" {
                    Text(item.mnemonic)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 12)
                }
            }
            .opacity(isFlipped ? 1 : 0)
            .rotation3DEffect(.degrees(isFlipped ? 0 : -180), axis: (x: 0, y: 1, z: 0))
        }
        .frame(maxWidth: 340)
        .frame(height: 360)
        .glassEffect(.regular, in: .rect(cornerRadius: 24))
    }

    // MARK: - Completion

    private var completionView: some View {
        VStack(spacing: 16) {
            Image(systemName: "star.fill")
                .font(.system(size: 50))
                .foregroundStyle(.yellow)

            Text("All Done!")
                .font(.title.bold())

            Text("You got \(gotItCount) of \(gotItCount + hardCount) cards right.")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Button("Play Again") {
                resetDeck()
            }
            .glassButton(tint: .blue)
        }
    }

    // MARK: - Actions

    private func markHard() {
        hardCount += 1
        let hardItem = deck[currentIndex]
        // Add hard items back to the end of the deck for spaced repetition
        deck.append(hardItem)
        advanceCard()
    }

    private func markGotIt() {
        gotItCount += 1
        haptics.playCorrectFeedback()
        advanceCard()
    }

    private func advanceCard() {
        withAnimation {
            isFlipped = false
        }
        // Brief delay before showing next card
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            withAnimation {
                currentIndex += 1
            }
        }
    }

    private func resetDeck() {
        deck = wordList.items.shuffled()
        currentIndex = 0
        hardCount = 0
        gotItCount = 0
        isFlipped = false
    }
}
