import SwiftUI

/// The translation result card, shown as a sheet after capturing an object
struct TranslationCardView: View {
    @EnvironmentObject var appState: AppState
    let vocabItem: VocabItem

    @State private var showListPicker = false
    @State private var showSaveConfirmation = false

    private let speech = SpeechService()
    private let haptics = HapticsService()

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Lifted subject image
                LiftedImageView(imageData: vocabItem.capturedImageData, maxHeight: 180)
                    .padding(.top, 20)

                // Source word
                HStack(spacing: 8) {
                    Text(vocabItem.sourceLanguage.flag)
                    Text(vocabItem.sourceWord)
                        .font(.title3)
                        .foregroundStyle(.secondary)
                }

                Image(systemName: "arrow.down")
                    .foregroundStyle(.secondary)
                    .font(.caption)

                // Target word (hero text)
                HStack(spacing: 8) {
                    Text(vocabItem.targetLanguage.flag)
                    Text(vocabItem.targetWord)
                        .font(.largeTitle.bold())
                }

                // Phonetic guide + speak button
                HStack(spacing: 12) {
                    Text("/\(vocabItem.phoneticGuide)/")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .italic()

                    Button {
                        speech.speak(vocabItem.targetWord, in: vocabItem.targetLanguage)
                    } label: {
                        Image(systemName: "speaker.wave.2.fill")
                            .foregroundStyle(.blue)
                    }
                    .glassIconButton()
                }

                // Example sentence card: source language first, then target
                if vocabItem.exampleSentence != "—" && !vocabItem.exampleSentence.contains("Enable Apple Intelligence") {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Example", systemImage: "text.quote")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.blue)

                        // Source language sentence (e.g. English)
                        HStack(alignment: .top, spacing: 6) {
                            Text(vocabItem.sourceLanguage.flag)
                            Text(vocabItem.exampleSentence)
                                .font(.subheadline)
                        }

                        // Target language translation (e.g. Spanish)
                        HStack(alignment: .top, spacing: 6) {
                            Text(vocabItem.targetLanguage.flag)
                            Text(vocabItem.mnemonic != "—" ? vocabItem.mnemonic : "")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .italic()
                        }

                        Button {
                            speech.speak(vocabItem.mnemonic, in: vocabItem.targetLanguage)
                        } label: {
                            Label("Listen", systemImage: "speaker.wave.2")
                                .font(.caption)
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(.blue)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .glassCard(cornerRadius: 16)
                }

                // Save button
                Button {
                    showListPicker = true
                } label: {
                    Label(showSaveConfirmation ? "Saved!" : "Save to List", systemImage: showSaveConfirmation ? "checkmark" : "square.and.arrow.down")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                .glassButton(tint: showSaveConfirmation ? .green : .blue)
                .padding(.top, 8)
                .padding(.horizontal)
            }
            .padding()
        }
        // Auto-speak the translated word when the card appears
        .onAppear {
            speech.speak(vocabItem.targetWord, in: vocabItem.targetLanguage)
        }
        .sheet(isPresented: $showListPicker) {
            ListPickerSheet(
                vocabItem: vocabItem,
                onSaved: {
                    haptics.playSaveFeedback()
                    showSaveConfirmation = true
                }
            )
            .presentationDetents([.medium])
        }
    }
}
