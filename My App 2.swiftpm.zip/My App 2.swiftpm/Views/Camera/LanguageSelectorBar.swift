import SwiftUI

/// Top overlay bar for selecting source and target languages on the camera screen
struct LanguageSelectorBar: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        HStack(spacing: 12) {
            // Source language picker
            Menu {
                ForEach(Language.allCases) { lang in
                    Button("\(lang.flag) \(lang.rawValue)") {
                        appState.sourceLanguage = lang
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Text(appState.sourceLanguage.flag)
                    Text(appState.sourceLanguage.rawValue)
                        .font(.subheadline.weight(.medium))
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .glassEffect(.regular, in: .capsule)
            }
            .buttonStyle(.plain)

            Image(systemName: "arrow.right")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.7))

            // Target language picker
            Menu {
                ForEach(Language.allCases) { lang in
                    Button("\(lang.flag) \(lang.rawValue)") {
                        appState.targetLanguage = lang
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Text(appState.targetLanguage.flag)
                    Text(appState.targetLanguage.rawValue)
                        .font(.subheadline.weight(.medium))
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .glassEffect(.regular, in: .capsule)
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 8)
    }
}
