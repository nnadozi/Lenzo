import SwiftUI
import CoreImage

/// The main camera screen (Tab 1): tap on an object to lift, identify, and translate it.
///
/// How it works:
/// 1. CameraPreview converts the tap into device-normalized coordinates
/// 2. We pass the raw pixel buffer + tap point to VisionPipeline
/// 3. Vision isolates the tapped subject (foreground instance mask)
/// 4. The lifted subject pops out with animation, then we translate it
struct CameraView: View {
    @EnvironmentObject var appState: AppState
    @StateObject private var cameraManager = CameraManager()

    @State private var isProcessing = false
    @State private var showTranslationCard = false
    @State private var currentVocabItem: VocabItem?

    // Hold-to-capture state
    @State private var tapScreenPoint: CGPoint?
    @State private var holdDevicePoint: CGPoint?
    @State private var isHolding = false          // finger is currently down
    @State private var holdCompleted = false       // 2-second countdown finished
    @State private var holdTask: Task<Void, Never>?

    // Pop-out animation for lifted subject
    @State private var liftedImage: UIImage?
    @State private var showLiftedPopOut = false

    private let visionPipeline = VisionPipeline()
    private let haptics = HapticsService()

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Live camera feed — press gestures handled inside CameraPreview
                if cameraManager.isAuthorized {
                    CameraPreview(
                        session: cameraManager.captureSession,
                        onTouchDown: { devicePoint in
                            handleTouchDown(devicePoint: devicePoint, in: geometry)
                        },
                        onTouchMoved: { devicePoint in
                            handleTouchMoved(devicePoint: devicePoint, in: geometry)
                        },
                        onTouchUp: {
                            handleTouchUp()
                        }
                    )
                    .ignoresSafeArea()
                } else {
                    cameraUnavailableView
                }

                // Shrinking countdown circle — visible while the user is holding
                if isHolding, let pt = tapScreenPoint {
                    HoldCountdownCircle(
                        radius: appState.selectionCircleRadius,
                        duration: 2.0
                    )
                    .position(pt)
                    .allowsHitTesting(false)
                }

                // Lifted subject pop-out overlay
                if showLiftedPopOut, let img = liftedImage {
                    liftedSubjectOverlay(image: img)
                        .transition(.scale.combined(with: .opacity))
                        .allowsHitTesting(false)
                }

                // Overlay UI
                VStack {
                    LanguageSelectorBar()
                        .padding(.top, 8)

                    Spacer()

                    if isProcessing {
                        processingIndicator
                            .padding(.bottom, 16)
                    } else if cameraManager.isAuthorized {
                        hintBar
                            .padding(.bottom, 16)
                    }
                }
                .padding(.horizontal)
            }
        }
        .onAppear { cameraManager.startSession() }
        .onDisappear { cameraManager.stopSession() }
        .onChange(of: cameraManager.isAuthorized) { _, ok in
            if ok { cameraManager.startSession() }
        }
        .sheet(isPresented: $showTranslationCard) {
            if let item = currentVocabItem {
                TranslationCardView(vocabItem: item)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
        }
    }

    // MARK: - Hold-to-Capture Gesture Handling

    /// Called the instant the user's finger touches the preview.
    /// Starts the shrinking countdown circle and schedules capture after 2 seconds.
    private func handleTouchDown(devicePoint: CGPoint, in geometry: GeometryProxy) {
        guard !isProcessing else { return }

        // Convert device coords to screen position for the countdown circle
        let screenX = devicePoint.x * geometry.size.width
        let screenY = devicePoint.y * geometry.size.height
        tapScreenPoint = CGPoint(x: screenX, y: screenY)
        holdDevicePoint = devicePoint
        holdCompleted = false

        withAnimation(.easeIn(duration: 0.1)) {
            isHolding = true
        }

        // Schedule capture after 2 seconds — cancelled if finger lifts early
        holdTask = Task {
            try? await Task.sleep(for: .seconds(2))
            guard !Task.isCancelled else { return }
            holdCompleted = true
            isHolding = false
            performCapture()
        }
    }

    /// Called as the user drags their finger — move the countdown circle
    /// and update the device point so capture targets the final position.
    private func handleTouchMoved(devicePoint: CGPoint, in geometry: GeometryProxy) {
        guard isHolding else { return }
        let screenX = devicePoint.x * geometry.size.width
        let screenY = devicePoint.y * geometry.size.height
        tapScreenPoint = CGPoint(x: screenX, y: screenY)
        holdDevicePoint = devicePoint
    }

    /// Called when the user lifts their finger. If the 2-second countdown
    /// hasn't finished, cancel the pending capture and hide the circle.
    private func handleTouchUp() {
        holdTask?.cancel()
        holdTask = nil

        if !holdCompleted {
            withAnimation(.easeOut(duration: 0.15)) {
                isHolding = false
            }
        }
    }

    /// Runs after the 2-second hold completes — lifts the subject and translates it.
    private func performCapture() {
        guard let devicePoint = holdDevicePoint else { return }
        guard let pixelBuffer = cameraManager.getCurrentFrame() else { return }

        Task {
            isProcessing = true
            if appState.hapticsEnabled { haptics.playCaptureFeedback() }

            guard let result = await visionPipeline.classifySubject(
                pixelBuffer: pixelBuffer,
                at: devicePoint
            ) else {
                isProcessing = false
                return
            }

            // If subject was lifted, show the pop-out animation before the card
            if result.wasSubjectLifted, let img = UIImage(data: result.croppedImageData) {
                liftedImage = img
                withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                    showLiftedPopOut = true
                }
                if appState.hapticsEnabled { haptics.playSuccessFeedback() }
                try? await Task.sleep(for: .milliseconds(800))
            }

            let translationService = TranslationService()
            let translation = await translationService.translate(
                classificationHints: result.topLabels,
                from: appState.sourceLanguage,
                to: appState.targetLanguage
            )

            let vocabItem = VocabItem(
                id: UUID(),
                capturedImageData: result.croppedImageData,
                classificationLabel: result.topLabels.first ?? "object",
                englishWord: translation.sourceWord,
                sourceWord: translation.sourceWord,
                sourceLanguage: appState.sourceLanguage,
                targetWord: translation.targetWord,
                targetLanguage: appState.targetLanguage,
                phoneticGuide: translation.phoneticGuide,
                exampleSentence: translation.exampleSentence,
                mnemonic: translation.mnemonic,
                capturedAt: Date()
            )

            if appState.hapticsEnabled { haptics.playSuccessFeedback() }
            currentVocabItem = vocabItem
            appState.capturedItems.append(vocabItem)

            withAnimation(.easeOut(duration: 0.2)) {
                showLiftedPopOut = false
            }
            liftedImage = nil

            showTranslationCard = true
            isProcessing = false
        }
    }

    // MARK: - UI Components

    /// Floating pop-out of the lifted subject on a glass card backdrop.
    private func liftedSubjectOverlay(image: UIImage) -> some View {
        VStack(spacing: 12) {
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 220, maxHeight: 220)
                .shadow(color: .black.opacity(0.3), radius: 12, y: 6)

            Text("Translating…")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(.secondary)
        }
        .padding(24)
        .glassEffect(.regular, in: .rect(cornerRadius: 24))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var processingIndicator: some View {
        HStack(spacing: 10) {
            ProgressView().tint(.primary)
            Text("Identifying...")
                .font(.subheadline.weight(.medium))
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .glassEffect(.regular, in: .capsule)
    }

    private var hintBar: some View {
        Text("Hold on an object for 2 seconds to identify and translate it")
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
            .glassEffect(.regular, in: .capsule)
    }

    private var cameraUnavailableView: some View {
        VStack(spacing: 16) {
            Image(systemName: "camera.fill")
                .font(.system(size: 50))
                .foregroundStyle(.secondary)
            Text("Camera Access Required")
                .font(.title3.weight(.semibold))
            Text("Open Settings and allow camera access for Lenzo to identify objects.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button("Open Settings") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            .glassButton(tint: .blue)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black)
    }
}

// MARK: - Hold Countdown Circle

/// A circle that starts at the user-configured radius and shrinks to zero over
/// the hold duration (2 seconds). When it disappears, the capture triggers.
/// Gives the user clear visual feedback of the countdown in progress.
private struct HoldCountdownCircle: View {
    let radius: Double
    let duration: Double

    @State private var progress: CGFloat = 0

    /// Current diameter — starts full, shrinks to zero
    private var currentSize: CGFloat {
        radius * 2 * (1 - progress)
    }

    var body: some View {
        ZStack {
            // Outer shrinking ring
            Circle()
                .stroke(Color.white.opacity(0.8), lineWidth: 3)
                .frame(width: currentSize, height: currentSize)

            // Faint filled center so the user can see the target area
            Circle()
                .fill(Color.white.opacity(0.12))
                .frame(width: currentSize, height: currentSize)
        }
        .onAppear {
            withAnimation(.linear(duration: duration)) {
                progress = 1
            }
        }
    }
}
