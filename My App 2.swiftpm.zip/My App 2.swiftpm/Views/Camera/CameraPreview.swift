import SwiftUI
import AVFoundation

/// UIViewRepresentable that displays the live AVCaptureSession preview.
/// Reports touch-down, move, and touch-up events with device-normalized coordinates
/// so that CameraView can run its own 2-second countdown animation.
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    /// Called when the user's finger touches down. Provides the device-normalized point.
    var onTouchDown: ((CGPoint) -> Void)?
    /// Called as the user drags their finger. Provides the updated device-normalized point.
    var onTouchMoved: ((CGPoint) -> Void)?
    /// Called when the user lifts their finger before the hold completes.
    var onTouchUp: (() -> Void)?

    func makeUIView(context: Context) -> CameraPreviewUIView {
        let view = CameraPreviewUIView()
        view.previewLayer.session = session
        view.previewLayer.videoGravity = .resizeAspectFill
        view.onTouchDown = onTouchDown
        view.onTouchMoved = onTouchMoved
        view.onTouchUp = onTouchUp
        return view
    }

    func updateUIView(_ uiView: CameraPreviewUIView, context: Context) {
        uiView.onTouchDown = onTouchDown
        uiView.onTouchMoved = onTouchMoved
        uiView.onTouchUp = onTouchUp
    }
}

/// Custom UIView that hosts an AVCaptureVideoPreviewLayer.
/// Uses a long-press gesture with near-zero minimum duration to detect
/// touch-down immediately, then reports touch-up or cancellation.
/// CameraView is responsible for the 2-second countdown logic.
class CameraPreviewUIView: UIView {
    let previewLayer = AVCaptureVideoPreviewLayer()
    var onTouchDown: ((CGPoint) -> Void)?
    var onTouchMoved: ((CGPoint) -> Void)?
    var onTouchUp: (() -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.addSublayer(previewLayer)

        // minimumPressDuration ~0 so .began fires instantly on finger-down.
        // CameraView handles the actual 2-second timing.
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handlePress(_:)))
        longPress.minimumPressDuration = 0.05
        addGestureRecognizer(longPress)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        previewLayer.frame = bounds
    }

    @objc private func handlePress(_ gesture: UILongPressGestureRecognizer) {
        switch gesture.state {
        case .began:
            let layerPoint = gesture.location(in: self)
            let devicePoint = previewLayer.captureDevicePointConverted(fromLayerPoint: layerPoint)
            onTouchDown?(devicePoint)
        case .changed:
            // Finger moved — update the position so the circle follows
            let layerPoint = gesture.location(in: self)
            let devicePoint = previewLayer.captureDevicePointConverted(fromLayerPoint: layerPoint)
            onTouchMoved?(devicePoint)
        case .ended, .cancelled, .failed:
            onTouchUp?()
        default:
            break
        }
    }
}
