import SwiftUI

/// Tab 3: Settings for appearance, haptics, app info, and onboarding reset
struct SettingsView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        NavigationStack {
            List {
                // Appearance
                Section("Appearance") {
                    Picker("Theme", selection: $appState.preferredAppearance) {
                        ForEach(AppAppearance.allCases) { appearance in
                            Text(appearance.rawValue).tag(appearance)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                // Haptics
                Section {
                    Toggle(isOn: $appState.hapticsEnabled) {
                        Label("Haptics", systemImage: "hand.tap")
                    }
                } footer: {
                    Text("Vibrate when objects are identified and translated.")
                }

                // Selection Circle Size
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Selection Circle Size", systemImage: "circle.dashed")
                        Slider(value: $appState.selectionCircleRadius, in: 20...60, step: 5) {
                            Text("Circle Radius")
                        } minimumValueLabel: {
                            Text("S").font(.caption2)
                        } maximumValueLabel: {
                            Text("L").font(.caption2)
                        }
                    }
                } footer: {
                    Text("Adjust the size of the selection circle shown when you hold on an object in the camera.")
                }

                // About
                Section("About") {
                    HStack {
                        Label("Version", systemImage: "info.circle")
                        Spacer()
                        Text("1.0.0")
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Label("Requirements", systemImage: "cpu")
                        Text("Lenzo requires Apple Intelligence (iOS 26+) for AI-powered translations. All processing happens on-device — no internet needed.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                // Reset
                Section {
                    Button(role: .destructive) {
                        appState.hasCompletedOnboarding = false
                    } label: {
                        Label("Replay Onboarding", systemImage: "arrow.counterclockwise")
                    }
                }
            }
            .navigationTitle("Settings")
        }
    }
}
