import SwiftUI

@main
struct LenzoApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .preferredColorScheme(appState.preferredAppearance.colorScheme)
        }
    }
}
