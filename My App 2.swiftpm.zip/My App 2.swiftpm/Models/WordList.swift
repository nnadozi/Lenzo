import Foundation

/// A user-created collection of vocabulary items
struct WordList: Identifiable, Codable, Sendable {
    let id: UUID
    var name: String
    var emoji: String
    var items: [VocabItem]
    let createdAt: Date

    var itemCount: Int { items.count }
}
