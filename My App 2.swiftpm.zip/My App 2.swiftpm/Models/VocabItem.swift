import Foundation

/// A single captured vocabulary item with its translation and learning aids
struct VocabItem: Identifiable, Codable, Sendable {
    let id: UUID
    let capturedImageData: Data
    let classificationLabel: String
    let englishWord: String
    let sourceWord: String
    let sourceLanguage: Language
    let targetWord: String
    let targetLanguage: Language
    let phoneticGuide: String
    let exampleSentence: String
    let mnemonic: String
    let capturedAt: Date
    var isStarred: Bool = false
}
