import Foundation

/// Themed categories of conversational phrases for language learners
enum PhraseCategory: String, CaseIterable, Identifiable, Codable, Sendable {
    case greetings = "Greetings"
    case restaurant = "Restaurant"
    case travel = "Travel"
    case shopping = "Shopping"
    case emergency = "Emergency"
    case smallTalk = "Small Talk"
    case directions = "Directions"
    case numbers = "Numbers & Time"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .greetings: return "hand.wave.fill"
        case .restaurant: return "fork.knife"
        case .travel: return "airplane"
        case .shopping: return "bag.fill"
        case .emergency: return "cross.circle.fill"
        case .smallTalk: return "bubble.left.and.bubble.right.fill"
        case .directions: return "map.fill"
        case .numbers: return "clock.fill"
        }
    }

    var color: String {
        switch self {
        case .greetings: return "orange"
        case .restaurant: return "red"
        case .travel: return "blue"
        case .shopping: return "purple"
        case .emergency: return "pink"
        case .smallTalk: return "green"
        case .directions: return "teal"
        case .numbers: return "indigo"
        }
    }

    var description: String {
        switch self {
        case .greetings: return "Hello, goodbye, and polite basics"
        case .restaurant: return "Order food, ask for the bill"
        case .travel: return "Airports, hotels, and getting around"
        case .shopping: return "Prices, sizes, and bargaining"
        case .emergency: return "Help, medical, and safety phrases"
        case .smallTalk: return "Weather, hobbies, and chitchat"
        case .directions: return "Ask and give directions"
        case .numbers: return "Counting, telling time, and dates"
        }
    }

    /// Seed phrases per category (in English) — used as prompts for AI generation
    var seedPhrases: [String] {
        switch self {
        case .greetings:
            return ["Hello", "Good morning", "Good night", "How are you?", "Nice to meet you", "Goodbye", "See you later", "Please", "Thank you", "You're welcome"]
        case .restaurant:
            return ["A table for two, please", "Can I see the menu?", "I'd like to order", "The check, please", "Water, please", "This is delicious", "I'm allergic to", "No spicy food, please", "Can I have the bill?", "A coffee, please"]
        case .travel:
            return ["Where is the airport?", "I need a taxi", "How much is a ticket?", "Where is the hotel?", "I have a reservation", "What time does it leave?", "Is this seat taken?", "I'm lost", "Where is the bathroom?", "Can you help me?"]
        case .shopping:
            return ["How much does this cost?", "That's too expensive", "Do you have a smaller size?", "Can I try this on?", "I'll take it", "Do you accept credit cards?", "Where is the store?", "Is there a discount?", "I'm just looking", "Can I return this?"]
        case .emergency:
            return ["Help!", "Call the police", "I need a doctor", "Where is the hospital?", "I'm not feeling well", "It's an emergency", "Fire!", "I lost my passport", "I need medicine", "Please call an ambulance"]
        case .smallTalk:
            return ["What's your name?", "Where are you from?", "What do you do?", "I like this place", "The weather is nice today", "Do you have any hobbies?", "How long have you been here?", "That's interesting", "I agree", "Tell me more"]
        case .directions:
            return ["Turn left", "Turn right", "Go straight", "It's on the corner", "How far is it?", "Is it nearby?", "Can you show me on the map?", "I'm looking for this address", "Which way to the center?", "Stop here, please"]
        case .numbers:
            return ["What time is it?", "One, two, three", "How many?", "Today is Monday", "What's the date?", "Half past ten", "Quarter to five", "It costs fifty", "I'll be there at noon", "How old are you?"]
        }
    }
}
