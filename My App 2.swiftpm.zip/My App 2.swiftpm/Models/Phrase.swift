import Foundation

/// A single conversational phrase with its translation and pronunciation
struct Phrase: Identifiable, Codable, Sendable {
    let id: UUID
    let category: PhraseCategory
    let sourcePhrase: String
    let sourceLanguage: Language
    let translatedPhrase: String
    let targetLanguage: Language
    let phoneticGuide: String
    let contextNote: String
    var isBookmarked: Bool = false
}
