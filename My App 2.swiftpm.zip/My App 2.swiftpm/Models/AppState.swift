import SwiftUI

@MainActor
class AppState: ObservableObject {
    @Published var hasCompletedOnboarding: Bool {
        didSet { UserDefaults.standard.set(hasCompletedOnboarding, forKey: "hasCompletedOnboarding") }
    }
    @Published var sourceLanguage: Language {
        didSet { UserDefaults.standard.set(sourceLanguage.rawValue, forKey: "sourceLanguage") }
    }
    @Published var targetLanguage: Language {
        didSet { UserDefaults.standard.set(targetLanguage.rawValue, forKey: "targetLanguage") }
    }
    @Published var wordLists: [WordList] {
        didSet { saveWordLists() }
    }
    @Published var capturedItems: [VocabItem] = []
    @Published var selectedTab: Int = 0

    @Published var bookmarkedPhrases: [Phrase] {
        didSet { saveBookmarkedPhrases() }
    }

    @Published var preferredAppearance: AppAppearance {
        didSet { UserDefaults.standard.set(preferredAppearance.rawValue, forKey: "preferredAppearance") }
    }

    /// Whether haptic feedback is enabled
    @Published var hapticsEnabled: Bool {
        didSet { UserDefaults.standard.set(hapticsEnabled, forKey: "hapticsEnabled") }
    }


    @Published var selectionCircleRadius: Double {
        didSet { UserDefaults.standard.set(selectionCircleRadius, forKey: "selectionCircleRadius") }
    }

    var totalItemsLearned: Int {
        wordLists.reduce(0) { $0 + $1.items.count }
    }

    init() {
        self.hasCompletedOnboarding = UserDefaults.standard.bool(forKey: "hasCompletedOnboarding")

        let sourceLangRaw = UserDefaults.standard.string(forKey: "sourceLanguage") ?? Language.english.rawValue
        self.sourceLanguage = Language(rawValue: sourceLangRaw) ?? .english

        let targetLangRaw = UserDefaults.standard.string(forKey: "targetLanguage") ?? Language.spanish.rawValue
        self.targetLanguage = Language(rawValue: targetLangRaw) ?? .spanish

        let appearanceRaw = UserDefaults.standard.string(forKey: "preferredAppearance") ?? AppAppearance.system.rawValue
        self.preferredAppearance = AppAppearance(rawValue: appearanceRaw) ?? .system

        // Haptics default to on
        if UserDefaults.standard.object(forKey: "hapticsEnabled") == nil {
            self.hapticsEnabled = true
        } else {
            self.hapticsEnabled = UserDefaults.standard.bool(forKey: "hapticsEnabled")
        }

        // Selection circle radius — default to largest size (60pt)
        if UserDefaults.standard.object(forKey: "selectionCircleRadius") == nil {
            self.selectionCircleRadius = 60
        } else {
            self.selectionCircleRadius = UserDefaults.standard.double(forKey: "selectionCircleRadius")
        }

        self.wordLists = AppState.loadWordLists()
        self.bookmarkedPhrases = AppState.loadBookmarkedPhrases()
    }

    // MARK: - Word List Management

    func addWordList(name: String, emoji: String) {
        let list = WordList(id: UUID(), name: name, emoji: emoji, items: [], createdAt: Date())
        wordLists.append(list)
    }

    func addItemToList(item: VocabItem, listId: UUID) {
        guard let index = wordLists.firstIndex(where: { $0.id == listId }) else { return }
        wordLists[index].items.append(item)
    }

    func removeItemFromList(itemId: UUID, listId: UUID) {
        guard let index = wordLists.firstIndex(where: { $0.id == listId }) else { return }
        wordLists[index].items.removeAll { $0.id == itemId }
    }

    func deleteWordList(id: UUID) {
        wordLists.removeAll { $0.id == id }
    }

    func toggleStarItem(itemId: UUID, listId: UUID) {
        guard let listIndex = wordLists.firstIndex(where: { $0.id == listId }),
              let itemIndex = wordLists[listIndex].items.firstIndex(where: { $0.id == itemId }) else { return }
        wordLists[listIndex].items[itemIndex].isStarred.toggle()
    }

    // MARK: - Persistence

    private static let wordListsKey = "savedWordLists"
    private static let bookmarkedPhrasesKey = "bookmarkedPhrases"

    private func saveWordLists() {
        guard let data = try? JSONEncoder().encode(wordLists) else { return }
        UserDefaults.standard.set(data, forKey: AppState.wordListsKey)
    }

    private static func loadWordLists() -> [WordList] {
        guard let data = UserDefaults.standard.data(forKey: wordListsKey),
              let lists = try? JSONDecoder().decode([WordList].self, from: data) else { return [] }
        return lists
    }

    // MARK: - Bookmark Management

    func toggleBookmark(for phrase: Phrase) {
        if let index = bookmarkedPhrases.firstIndex(where: { $0.id == phrase.id }) {
            bookmarkedPhrases.remove(at: index)
        } else {
            var bookmarked = phrase
            bookmarked.isBookmarked = true
            bookmarkedPhrases.append(bookmarked)
        }
    }

    func isBookmarked(_ phrase: Phrase) -> Bool {
        bookmarkedPhrases.contains(where: { $0.id == phrase.id })
    }

    private func saveBookmarkedPhrases() {
        guard let data = try? JSONEncoder().encode(bookmarkedPhrases) else { return }
        UserDefaults.standard.set(data, forKey: AppState.bookmarkedPhrasesKey)
    }

    private static func loadBookmarkedPhrases() -> [Phrase] {
        guard let data = UserDefaults.standard.data(forKey: bookmarkedPhrasesKey),
              let phrases = try? JSONDecoder().decode([Phrase].self, from: data) else { return [] }
        return phrases
    }
}

/// User-selectable appearance mode
enum AppAppearance: String, CaseIterable, Identifiable, Sendable {
    case system = "System"
    case light = "Light"
    case dark = "Dark"

    var id: String { rawValue }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
