import Foundation

/// Supported languages for translation with display info and locale codes
enum Language: String, CaseIterable, Identifiable, Codable, Sendable {
    case english = "English"
    case spanish = "Spanish"
    case french = "French"
    case german = "German"
    case italian = "Italian"
    case portuguese = "Portuguese"
    case japanese = "Japanese"
    case korean = "Korean"
    case chineseSimplified = "Chinese (Simplified)"
    case arabic = "Arabic"
    case hindi = "Hindi"
    case russian = "Russian"
    case turkish = "Turkish"
    case dutch = "Dutch"
    case swedish = "Swedish"
    case thai = "Thai"
    case vietnamese = "Vietnamese"

    var id: String { rawValue }

    var flag: String {
        switch self {
        case .english: return "🇺🇸"
        case .spanish: return "🇪🇸"
        case .french: return "🇫🇷"
        case .german: return "🇩🇪"
        case .italian: return "🇮🇹"
        case .portuguese: return "🇧🇷"
        case .japanese: return "🇯🇵"
        case .korean: return "🇰🇷"
        case .chineseSimplified: return "🇨🇳"
        case .arabic: return "🇸🇦"
        case .hindi: return "🇮🇳"
        case .russian: return "🇷🇺"
        case .turkish: return "🇹🇷"
        case .dutch: return "🇳🇱"
        case .swedish: return "🇸🇪"
        case .thai: return "🇹🇭"
        case .vietnamese: return "🇻🇳"
        }
    }

    var bcp47Code: String {
        switch self {
        case .english: return "en-US"
        case .spanish: return "es-ES"
        case .french: return "fr-FR"
        case .german: return "de-DE"
        case .italian: return "it-IT"
        case .portuguese: return "pt-BR"
        case .japanese: return "ja-JP"
        case .korean: return "ko-KR"
        case .chineseSimplified: return "zh-CN"
        case .arabic: return "ar-SA"
        case .hindi: return "hi-IN"
        case .russian: return "ru-RU"
        case .turkish: return "tr-TR"
        case .dutch: return "nl-NL"
        case .swedish: return "sv-SE"
        case .thai: return "th-TH"
        case .vietnamese: return "vi-VN"
        }
    }
}
