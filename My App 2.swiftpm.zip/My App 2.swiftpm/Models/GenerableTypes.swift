import FoundationModels

// MARK: - AI-Generable Types
// When FoundationModels is available (e.g. on-device with Apple Intelligence),
// these structs use @Generable/@Guide so the language model can produce them.
// When it's not (e.g. Swift Playgrounds), they compile as plain structs and
// the app falls back to the bundled FallbackDictionary.

/// Translation output from the on-device language model
@Generable
struct TranslationResult {
    @Guide(description: "The object name in the source language")
    var sourceWord: String
    @Guide(description: "The translated word in the target language")
    var targetWord: String
    @Guide(description: "Phonetic/pronunciation guide using English letters, e.g. 'lah TAH-sah'")
    var phoneticGuide: String
    @Guide(description: "An example sentence written in the SOURCE language (e.g. English) that uses or relates to the object")
    var exampleSentence: String
    @Guide(description: "The translation of exampleSentence into the TARGET language")
    var mnemonic: String
}

/// Sentence generation output for practice exercises
@Generable
struct SentenceGeneration {
    @Guide(description: "A natural sentence in the target language using the given word")
    var sentence: String
    @Guide(description: "English translation of the sentence")
    var englishTranslation: String
}

/// Quiz distractor words for multiple choice
@Generable
struct QuizDistractors {
    @Guide(description: "Three plausible but incorrect translation options")
    var distractors: [String]
}

/// Fill-in-the-blank exercise data
@Generable
struct FillInTheBlank {
    @Guide(description: "Sentence in target language with ______ replacing the target word")
    var sentenceWithBlank: String
    @Guide(description: "English translation with ______ in the same position")
    var englishHint: String
    @Guide(description: "The correct answer word")
    var answer: String
}

/// AI-generated phrase translation with pronunciation and usage context
@Generable
struct PhraseTranslation {
    @Guide(description: "The phrase translated into the target language")
    var translatedPhrase: String
    @Guide(description: "Phonetic/pronunciation guide using English letters, e.g. 'OH-lah, KO-mo ehs-TAHS'")
    var phoneticGuide: String
    @Guide(description: "A short note about when or how to use this phrase, e.g. 'Casual greeting among friends'")
    var contextNote: String
}

/// Chatbot reply for phrase Q&A conversations
@Generable
struct PhraseChatReply {
    @Guide(description: "A helpful, concise answer to the user's question about the phrase. Include translations, examples, or cultural context as appropriate.")
    var reply: String
}

/// A single turn in an AI conversation partner exchange
@Generable
struct ConversationTurn {
    @Guide(description: "The AI partner's reply in the TARGET language the user is learning")
    var targetLanguageText: String
    @Guide(description: "Phonetic pronunciation guide for the target language text using English letters")
    var phoneticGuide: String
    @Guide(description: "English translation of the AI partner's reply")
    var englishTranslation: String
    @Guide(description: "Three short suggested replies the user could say next, written in the TARGET language. Keep them simple and natural for a learner.")
    var suggestedReplies: [String]
}
